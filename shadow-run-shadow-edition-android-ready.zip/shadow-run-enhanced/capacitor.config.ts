import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.nightfall.shadowrun',
  appName: 'Shadow Run',
  webDir: 'dist',
  bundledWebRuntime: false,
  android: {
    backgroundColor: '#070910',
    allowMixedContent: false,
  },
};

export default config;
