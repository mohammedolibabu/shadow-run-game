# Shadow Run — Shadow Edition

This project is a React + Three.js + Vite game with a refreshed dark/crimson visual style and Capacitor Android configuration.

## Run as a website

Requires Node.js 20 or newer.

```bash
npm install
npm run dev
```

To create the production web build:

```bash
npm run build
```

The production site is generated in `dist/`.

## Build an Android APK (cloud build; no local computer required after uploading)

This repository includes `.github/workflows/android-apk.yml`. It builds a **debug APK** using GitHub Actions.

1. Upload this project folder to a GitHub repository (keep the `.github/workflows/android-apk.yml` file).
2. Open the repository's **Actions** tab.
3. Select **Build Shadow Run APK**.
4. Tap **Run workflow** and run it on the default branch. A push to `main` or `master` also starts a build.
5. When the run completes, open the run and download the `shadow-run-debug-apk` artifact.
6. Extract the downloaded artifact ZIP to get `app-debug.apk`.

The workflow builds a debug APK for testing. It is not a signed Play Store release. The first build downloads packages and may take several minutes. You must have permission to use the GitHub account/repository. No APK is included in this source ZIP because it must be compiled by the Android build environment.

## Local Android build

Requires Node.js, Java 21, Android Studio and Android SDK.

```bash
npm install
npm run build
npx cap add android
npx cap sync android
npx cap open android
```

In Android Studio, use **Build > Build Bundle(s) / APK(s) > Build APK(s)** for a debug APK. For a release build, use **Generate Signed Bundle / APK** and create/manage a signing key securely.
