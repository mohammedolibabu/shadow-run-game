import { useEffect, useRef, useState, type ReactNode } from 'react';
import {
  Activity, ArrowDown, ArrowLeft, ArrowRight, ArrowUp, Award, BookOpen, Camera,
  Check, CheckCircle2, ChevronLeft, ChevronRight, Circle, Coins, Crosshair, Crown,
  Download, Gauge, Gem, Hand, Heart, HeartPulse, Home, Info, Keyboard,
  Lock, Magnet, Map, Music, Pause, Play, RotateCcw, Settings, Shield, ShieldCheck,
  Skull, Smartphone, Sparkles, Star, Sun, Sword, Swords, Target,
  Trophy, Users, Vibrate, Volume2, Wand2, Wind, Zap,
} from 'lucide-react';
import { ShadowRunEngine, type GameSnapshot } from './game/ShadowRunEngine';
import {
  ACHIEVEMENTS, BIOMES, CHARACTERS, POWERUPS, WEAPONS, getCharacter, getWeapon,
  type CharacterDef, type CharacterId, type GraphicsQuality, type PowerupType, type WeaponId,
} from './game/content';
import {
  applyRunResult, checkCollectionAchievements, defaultSave, emptyUpgrades, loadSave,
  storeSave, upgradeCost, type RunResult, type SaveData, type Settings as SaveSettings,
} from './game/save';
import { GameAudio } from './game/audio';

const cx = (...values: Array<string | false | null | undefined>) => values.filter(Boolean).join(' ');
const number = (value: number) => Math.floor(value).toLocaleString();
type Screen = 'menu' | 'characters' | 'armory' | 'records' | 'settings' | 'guide' | 'game';
type Toast = { text: string; tone: 'info' | 'danger' | 'reward'; id: number };

function WeaponGlyph({ id, size = 22 }: { id: WeaponId; size?: number }) {
  if (id === 'iceStaff') return <Wand2 size={size} />;
  if (id === 'thunderBlade') return <Zap size={size} />;
  if (id === 'energyBow') return <Target size={size} />;
  if (id === 'phoenixOrb') return <Sun size={size} />;
  if (id === 'shadowDaggers') return <Swords size={size} />;
  return <Sword size={size} />;
}

function PowerupGlyph({ type, size = 15 }: { type: PowerupType; size?: number }) {
  if (type === 'shield') return <Shield size={size} />;
  if (type === 'magnet') return <Magnet size={size} />;
  if (type === 'boost') return <Wind size={size} />;
  if (type === 'jump') return <ArrowUp size={size} />;
  if (type === 'heal') return <HeartPulse size={size} />;
  return <Sparkles size={size} />;
}

function CharacterArt({ character, large = false }: { character: CharacterDef; large?: boolean }) {
  const c = character.colors;
  const isHood = ['hood', 'veil', 'void'].includes(character.model);
  return (
    <div className={cx('character-art', large && 'character-art--large')} style={{ '--hero': c.primary, '--hero2': c.secondary, '--accent': c.accent } as React.CSSProperties}>
      <svg viewBox="0 0 220 260" role="img" aria-label={`${character.name}, ${character.title}`}>
        <defs>
          <linearGradient id={`bg-${character.id}`} x1="0" y1="0" x2="1" y2="1"><stop stopColor={c.secondary} /><stop offset="1" stopColor="#080b12" /></linearGradient>
          <linearGradient id={`armor-${character.id}`} x1="0" y1="0" x2="0.8" y2="1"><stop stopColor={c.secondary} /><stop offset="0.55" stopColor={c.primary} /><stop offset="1" stopColor="#090b11" /></linearGradient>
          <radialGradient id={`glow-${character.id}`}><stop stopColor={c.accent} stopOpacity=".5" /><stop offset="1" stopColor={c.accent} stopOpacity="0" /></radialGradient>
          <filter id={`blur-${character.id}`}><feGaussianBlur stdDeviation="5" /></filter>
        </defs>
        <rect width="220" height="260" rx="18" fill={`url(#bg-${character.id})`} />
        <circle cx="110" cy="99" r="86" fill={`url(#glow-${character.id})`} />
        <g opacity=".16" stroke={c.accent} fill="none">
          <circle cx="110" cy="110" r="73" /><circle cx="110" cy="110" r="61" strokeDasharray="3 8" />
          <path d="M110 24v18M110 178v18M24 110h18M178 110h18M49 49l13 13M158 158l13 13M171 49l-13 13M62 158l-13 13" />
        </g>
        <ellipse cx="110" cy="238" rx="69" ry="13" fill="#02040a" opacity=".6" filter={`url(#blur-${character.id})`} />
        <path d="M57 239c2-54 16-88 42-96h24c28 8 40 45 42 96z" fill={`url(#armor-${character.id})`} stroke={c.secondary} strokeWidth="2" />
        <path d="M67 181l-25 53h26l19-46M153 181l25 53h-26l-19-46" fill={c.primary} stroke={c.secondary} strokeWidth="3" />
        <path d="M83 150l-18 18 18 15M137 150l18 18-18 15" fill={c.secondary} stroke={c.accent} strokeOpacity=".45" />
        <path d="M89 147l2-19h38l2 19-20 18z" fill={c.skin} />
        {isHood ? <>
          <path d="M71 116c0-50 19-76 41-76s41 28 40 76l-17 33H87z" fill={c.primary} stroke={c.secondary} strokeWidth="4" />
          <path d="M84 113c0-31 11-51 28-51s28 20 28 51l-12 26H96z" fill="#10131b" />
          <path d="M92 99c3-22 10-31 20-31s18 10 20 31l-7 30H99z" fill={c.skin} opacity=".82" />
        </> : <>
          <ellipse cx="111" cy="102" rx="35" ry="43" fill={c.skin} />
          <path d="M77 99c-2-42 14-61 36-61 29 0 39 27 34 62l-12-28-42-4-10 34z" fill={c.primary} stroke={c.secondary} strokeWidth="3" />
        </>}
        <path d="M94 101l12-2M117 99l12 2" stroke={c.accent} strokeWidth="3" strokeLinecap="round" />
        <path d="M104 121l8 2 8-2" stroke="#321f24" strokeWidth="2" fill="none" />
        {character.model === 'crown' && <path d="M77 66l4-35 20 20 11-34 13 34 20-20 1 36z" fill={c.secondary} stroke={c.accent} strokeWidth="3" />}
        {(character.model === 'mohawk' || character.model === 'phoenix') && <path d="M99 48l-4-33 15 17 5-28 9 29 14-17-7 36z" fill={c.accent} opacity=".9" />}
        {character.model === 'horns' && <><path d="M82 66L52 25l9 50z" fill={c.secondary} /><path d="M140 66l30-41-9 50z" fill={c.secondary} /></>}
        {character.model === 'topknot' && <path d="M102 40c-8-23 5-35 17-24 8 8 1 17-3 25z" fill={c.secondary} />}
        {character.model === 'ribbons' && <><path d="M78 72C43 104 61 147 43 172" stroke={c.accent} strokeWidth="6" fill="none" /><path d="M143 71c33 34 15 73 35 101" stroke={c.accent} strokeWidth="6" fill="none" /></>}
        {character.model === 'helm' && <path d="M75 105V76c0-31 17-46 37-46s37 16 37 46v29l-15-21H91z" fill={c.secondary} stroke={c.accent} strokeWidth="2" opacity=".9" />}
        <path d="M110 164l10 14-10 17-10-17z" fill={c.accent} /><circle cx="110" cy="179" r="24" fill={c.accent} opacity=".12" filter={`url(#blur-${character.id})`} />
        <path d="M92 211h36M86 226h48" stroke={c.secondary} strokeWidth="3" opacity=".8" />
      </svg>
      <span className="art-level">SR</span>
    </div>
  );
}

function IconButton({ label, children, onClick, className = '', disabled = false }: { label: string; children: ReactNode; onClick?: () => void; className?: string; disabled?: boolean }) {
  return <button className={`icon-button ${className}`} onClick={onClick} aria-label={label} title={label} disabled={disabled}>{children}</button>;
}

function CoinBalance({ coins }: { coins: number }) {
  return <div className="coin-balance"><Coins size={17} /><span>{number(coins)}</span></div>;
}

function initialSnapshot(character: CharacterId, weapon: WeaponId): GameSnapshot {
  return {
    distance: 0, score: 0, coins: 0, health: getCharacter(character).stats.health, maxHealth: getCharacter(character).stats.health,
    shield: 0, threat: 0, combo: 0, biome: BIOMES[0].name, biomeIndex: 0, weapon,
    abilityCooldown: 0, abilityTotal: getCharacter(character).ability.cooldown, boss: null, powerups: {}, speed: 1, assassinAttack: false,
  };
}

export default function App() {
  const [save, setSave] = useState<SaveData>(() => loadSave());
  const [screen, setScreen] = useState<Screen>('menu');
  const [previewId, setPreviewId] = useState<CharacterId>(save.selectedCharacter);
  const [runId, setRunId] = useState(0);
  const [paused, setPaused] = useState(false);
  const [result, setResult] = useState<RunResult | null>(null);
  const [snapshot, setSnapshot] = useState<GameSnapshot>(() => initialSnapshot(save.selectedCharacter, save.selectedWeapon));
  const [toast, setToast] = useState<Toast | null>(null);
  const [newAchievements, setNewAchievements] = useState<string[]>([]);
  const gameContainer = useRef<HTMLDivElement>(null);
  const engine = useRef<ShadowRunEngine | null>(null);
  const audio = useRef<GameAudio>(new GameAudio());
  const saveRef = useRef(save);
  const pausedRef = useRef(false);
  const toastTimer = useRef<number | undefined>(undefined);
  const character = getCharacter(save.selectedCharacter);
  const preview = getCharacter(previewId);
  const weapon = getWeapon(save.selectedWeapon);

  useEffect(() => { saveRef.current = save; }, [save]);
  useEffect(() => { audio.current.setVolumes(save.settings.music, save.settings.sfx); }, [save.settings.music, save.settings.sfx]);
  useEffect(() => () => audio.current.dispose(), []);

  const notify = (text: string, tone: Toast['tone'] = 'info') => {
    if (toastTimer.current) window.clearTimeout(toastTimer.current);
    setToast({ text, tone, id: Date.now() });
    toastTimer.current = window.setTimeout(() => setToast(null), 2800);
  };

  const requestPause = () => {
    if (result || screen !== 'game') return;
    if (pausedRef.current) {
      pausedRef.current = false; setPaused(false); engine.current?.resume();
    } else {
      pausedRef.current = true; setPaused(true); engine.current?.pause();
    }
  };

  useEffect(() => {
    if (screen !== 'game' || !gameContainer.current || runId === 0) return;
    const current = saveRef.current;
    const upgrades = current.upgrades[current.selectedCharacter] ?? emptyUpgrades();
    const instance = new ShadowRunEngine({
      container: gameContainer.current,
      characterId: current.selectedCharacter,
      weaponId: current.selectedWeapon,
      unlockedWeapons: current.unlockedWeapons,
      upgrades,
      settings: current.settings,
      audio: audio.current,
      onSnapshot: setSnapshot,
      onToast: notify,
      onPauseRequest: requestPause,
      onGameOver: (runResult) => {
        const progress = applyRunResult(saveRef.current, runResult);
        saveRef.current = progress.save; setSave(progress.save); setResult(runResult);
        setNewAchievements(progress.unlockedAchievements);
        pausedRef.current = false; setPaused(false);
      },
    });
    engine.current = instance;
    return () => { instance.dispose(); if (engine.current === instance) engine.current = null; };
    // A new run intentionally captures the selected loadout and settings once.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [runId, screen]);

  const startRun = () => {
    audio.current.unlock(); audio.current.sfx('select');
    setResult(null); setNewAchievements([]); setPaused(false); pausedRef.current = false;
    setSnapshot(initialSnapshot(save.selectedCharacter, save.selectedWeapon));
    setScreen('game'); setRunId((id) => id + 1);
  };

  const goMenu = () => { setResult(null); setPaused(false); pausedRef.current = false; setScreen('menu'); };

  const updateSave = (next: SaveData, checkCollection = false) => {
    if (checkCollection) {
      const progress = checkCollectionAchievements(next);
      saveRef.current = progress.save; setSave(progress.save);
      if (progress.unlockedAchievements.length) notify(`ACHIEVEMENT UNLOCKED · +${progress.earnedRewards} COINS`, 'reward');
    } else {
      storeSave(next); saveRef.current = next; setSave(next);
    }
  };

  const unlockOrSelectCharacter = () => {
    const unlocked = save.unlockedCharacters.includes(preview.id);
    if (unlocked) {
      updateSave({ ...save, selectedCharacter: preview.id }); audio.current.sfx('select'); notify(`${preview.name.toUpperCase()} SELECTED`, 'info');
    } else if (save.coins >= preview.cost) {
      const next: SaveData = { ...save, coins: save.coins - preview.cost, selectedCharacter: preview.id, unlockedCharacters: [...save.unlockedCharacters, preview.id] };
      updateSave(next, true); audio.current.sfx('powerup'); notify(`${preview.name.toUpperCase()} JOINED THE REBELLION`, 'reward');
    } else notify(`NEED ${number(preview.cost - save.coins)} MORE COINS`, 'danger');
  };

  const buyUpgrade = (key: 'vitality' | 'focus' | 'fortune') => {
    if (!save.unlockedCharacters.includes(preview.id)) return;
    const current = save.upgrades[preview.id] ?? emptyUpgrades();
    const level = current[key]; if (level >= 5) return;
    const cost = upgradeCost(level, CHARACTERS.findIndex((c) => c.id === preview.id));
    if (save.coins < cost) { notify(`NEED ${number(cost - save.coins)} MORE COINS`, 'danger'); return; }
    const upgrades = { ...save.upgrades, [preview.id]: { ...current, [key]: level + 1 } };
    updateSave({ ...save, coins: save.coins - cost, upgrades }); audio.current.sfx('powerup'); notify(`${key.toUpperCase()} UPGRADED TO LEVEL ${level + 1}`, 'reward');
  };

  const unlockOrEquipWeapon = (id: WeaponId) => {
    const def = getWeapon(id); const unlocked = save.unlockedWeapons.includes(id);
    if (unlocked) { updateSave({ ...save, selectedWeapon: id }); audio.current.sfx('select'); notify(`${def.name.toUpperCase()} EQUIPPED`, 'info'); }
    else if (save.coins >= def.cost) {
      updateSave({ ...save, coins: save.coins - def.cost, selectedWeapon: id, unlockedWeapons: [...save.unlockedWeapons, id] }, true);
      audio.current.sfx('powerup'); notify(`${def.name.toUpperCase()} FORGED`, 'reward');
    } else notify(`NEED ${number(def.cost - save.coins)} MORE COINS`, 'danger');
  };

  const updateSettings = <K extends keyof SaveSettings>(key: K, value: SaveSettings[K]) => {
    const next = { ...save, settings: { ...save.settings, [key]: value } };
    updateSave(next);
    if (key === 'sfx') audio.current.sfx('select');
  };

  const resetProgress = () => {
    if (!window.confirm('Erase all characters, coins, upgrades, records, and achievements? This cannot be undone.')) return;
    const fresh = defaultSave(); updateSave(fresh); setPreviewId('kael'); notify('LOCAL PROGRESS RESET', 'info');
  };

  return (
    <main className="app-shell">
      {screen === 'menu' && <MainMenu save={save} character={character} weaponName={weapon.name} onStart={startRun} onNavigate={setScreen} />}
      {screen === 'characters' && (
        <CharacterScreen save={save} preview={preview} onPreview={setPreviewId} onBack={goMenu} onAction={unlockOrSelectCharacter} onUpgrade={buyUpgrade} />
      )}
      {screen === 'armory' && <ArmoryScreen save={save} onBack={goMenu} onAction={unlockOrEquipWeapon} />}
      {screen === 'records' && <RecordsScreen save={save} onBack={goMenu} />}
      {screen === 'settings' && <SettingsScreen save={save} onBack={goMenu} onChange={updateSettings} onReset={resetProgress} onGuide={() => setScreen('guide')} />}
      {screen === 'guide' && <GuideScreen onBack={goMenu} />}
      {screen === 'game' && (
        <section className={cx('game-screen', save.settings.leftHanded && 'left-handed')}>
          <div className="game-viewport" ref={gameContainer} />
          <div className={cx('threat-vignette', snapshot.threat > 0.62 && 'danger')} style={{ opacity: Math.max(0, (snapshot.threat - 0.35) * 0.85) }} />
          {snapshot.speed > 1 && <div className="speed-lines" />}
          {!result && <GameHUD snapshot={snapshot} character={character} weapon={getWeapon(snapshot.weapon)} paused={paused} onPause={requestPause} engine={engine} />}
          {snapshot.boss?.intro && !result && <BossIntro snapshot={snapshot} />}
          {paused && !result && <PauseMenu save={save} onResume={requestPause} onRestart={startRun} onEnd={() => engine.current?.endRun('The hunt ended at the sanctuary')} onVolume={updateSettings} />}
          {result && <GameOver result={result} save={save} achievements={newAchievements} onRestart={startRun} onMenu={goMenu} />}
        </section>
      )}
      {toast && <div key={toast.id} className={`game-toast ${toast.tone}`}><span />{toast.text}<span /></div>}
    </main>
  );
}

function MainMenu({ save, character, weaponName, onStart, onNavigate }: { save: SaveData; character: CharacterDef; weaponName: string; onStart: () => void; onNavigate: (screen: Screen) => void }) {
  return (
    <section className="main-menu">
      <div className="key-art" />
      <div className="menu-grain" />
      <header className="menu-topbar">
        <div className="brand-mini"><span className="brand-mark"><Sword size={17} /></span><span>NIGHTFALL<br /><b>INTERACTIVE</b></span></div>
        <div className="menu-top-actions"><CoinBalance coins={save.coins} /><IconButton label="Settings" onClick={() => onNavigate('settings')}><Settings size={20} /></IconButton></div>
      </header>
      <div className="hero-content">
        <div className="eyebrow"><span /> A SUPERNATURAL ENDLESS RUNNER <span /></div>
        <h1><span>SHADOW</span> RUN</h1>
        <div className="title-rule"><i /><h2>THE ASSASSIN</h2><i /></div>
        <p className="hero-copy">Outrun the hunter. Master the arcane.<br />Break the guardians of five fallen realms.</p>
        <button className="primary-cta" onClick={onStart}><span className="cta-icon"><Play size={23} fill="currentColor" /></span><span><small>BEGIN THE HUNT</small>START RUN</span><ChevronRight size={24} /></button>
        <div className="loadout-strip">
          <CharacterArt character={character} />
          <div><small>ACTIVE ASSASSIN</small><strong>{character.name} <span>· {character.title}</span></strong><p><Sparkles size={13} /> {character.ability.name}<i /> <WeaponGlyph id={save.selectedWeapon} size={13} /> {weaponName}</p></div>
          <button onClick={() => onNavigate('characters')}>CHANGE <ChevronRight size={15} /></button>
        </div>
      </div>
      <aside className="menu-records">
        <div><small>PERSONAL BEST</small><strong>{number(save.bestScore)}</strong><span>SCORE</span></div>
        <div><small>LONGEST RUN</small><strong>{number(save.bestDistance)}<em>m</em></strong><span>DISTANCE</span></div>
        <div><small>GUARDIANS</small><strong>{number(save.bossesDefeated)}</strong><span>BANISHED</span></div>
      </aside>
      <div className="realm-ticker"><span><Map size={14} /> WORLD CIRCUIT</span>{BIOMES.map((biome, index) => <div key={biome.id}><i style={{ background: biome.accent }} />{biome.name}<small>{index === 0 ? 'START' : `${index * 100}m`}</small></div>)}</div>
      <nav className="main-nav">
        <button onClick={() => onNavigate('characters')}><Users size={20} /><span>CHARACTERS</span><small>{save.unlockedCharacters.length}/10 UNLOCKED</small></button>
        <button onClick={() => onNavigate('armory')}><Swords size={20} /><span>ARCANE ARMORY</span><small>{save.unlockedWeapons.length}/6 WEAPONS</small></button>
        <button onClick={() => onNavigate('records')}><Trophy size={20} /><span>ACHIEVEMENTS</span><small>{save.achievements.length}/10 COMPLETE</small></button>
        <button onClick={() => onNavigate('guide')}><BookOpen size={20} /><span>FIELD GUIDE</span><small>CONTROLS & ANDROID</small></button>
      </nav>
      <div className="build-label"><span /> 3D WEB / ANDROID READY <b>v1.0</b></div>
    </section>
  );
}

function ScreenHeader({ title, subtitle, coins, onBack }: { title: string; subtitle: string; coins?: number; onBack: () => void }) {
  return <header className="screen-header"><IconButton label="Back" onClick={onBack}><ChevronLeft size={23} /></IconButton><div><small>SHADOW RUN</small><h2>{title}</h2><p>{subtitle}</p></div>{coins !== undefined ? <CoinBalance coins={coins} /> : <span className="header-sigil"><Sword size={21} /></span>}</header>;
}

function CharacterScreen({ save, preview, onPreview, onBack, onAction, onUpgrade }: { save: SaveData; preview: CharacterDef; onPreview: (id: CharacterId) => void; onBack: () => void; onAction: () => void; onUpgrade: (key: 'vitality' | 'focus' | 'fortune') => void }) {
  const unlocked = save.unlockedCharacters.includes(preview.id);
  const selected = save.selectedCharacter === preview.id;
  const upgrades = save.upgrades[preview.id] ?? emptyUpgrades();
  const upgradeInfo = [
    { key: 'vitality' as const, name: 'Vitality', icon: <Heart size={17} />, description: '+1 max health every 2 levels' },
    { key: 'focus' as const, name: 'Arcane Focus', icon: <Sparkles size={17} />, description: 'Faster attacks & ability recharge' },
    { key: 'fortune' as const, name: 'Fortune', icon: <Coins size={17} />, description: '+8% bonus coin chance per level' },
  ];
  return (
    <section className="sub-screen character-screen">
      <ScreenHeader title="THE REBELLION" subtitle="Choose your assassin. Forge their legend." coins={save.coins} onBack={onBack} />
      <div className="character-layout">
        <div className="character-grid">
          {CHARACTERS.map((item, index) => {
            const owned = save.unlockedCharacters.includes(item.id);
            return <button key={item.id} className={cx('character-card', preview.id === item.id && 'active', save.selectedCharacter === item.id && 'selected')} onClick={() => onPreview(item.id)} style={{ '--card-accent': item.colors.accent } as React.CSSProperties}>
              <CharacterArt character={item} />
              <div className="character-card-copy"><small>{String(index + 1).padStart(2, '0')} · {item.title}</small><strong>{item.name}</strong><span>{owned ? <><Check size={12} /> AVAILABLE</> : <><Lock size={12} /> {number(item.cost)}</>}</span></div>
              {save.selectedCharacter === item.id && <i className="selected-tag">ACTIVE</i>}
            </button>;
          })}
        </div>
        <aside className="character-detail" style={{ '--detail-accent': preview.colors.accent } as React.CSSProperties}>
          <div className="detail-portrait"><CharacterArt character={preview} large /><div className="detail-number">{String(CHARACTERS.indexOf(preview) + 1).padStart(2, '0')}</div></div>
          <div className="detail-title"><small>{preview.title}</small><h3>{preview.name}</h3><p>{preview.lore}</p></div>
          <div className="stat-row"><span><Heart size={15} /> VITALITY <b>{preview.stats.health}</b></span><span><Gauge size={15} /> AGILITY <b>{Math.round(preview.stats.speed * 100)}</b></span><span><Sword size={15} /> POWER <b>{Math.round(preview.stats.power * 100)}</b></span></div>
          <div className="ability-card"><div className="ability-icon"><Sparkles size={22} /></div><div><small>SIGNATURE ABILITY · {preview.ability.cooldown}s COOLDOWN</small><strong>{preview.ability.name}</strong><p>{preview.ability.description}</p><span><Star size={12} /> PASSIVE: {preview.perk}</span></div></div>
          <button className={cx('wide-action', selected && 'selected')} onClick={onAction} disabled={selected}>
            {selected ? <><CheckCircle2 size={19} /> ACTIVE CHARACTER</> : unlocked ? <><Play size={18} /> SELECT {preview.name.toUpperCase()}</> : save.coins >= preview.cost ? <><Lock size={18} /> UNLOCK · {number(preview.cost)} <Coins size={16} /></> : <><Lock size={18} /> LOCKED · {number(preview.cost)} <Coins size={16} /></>}
          </button>
          <div className="upgrade-section"><div className="section-label"><span>CHARACTER UPGRADES</span><small>PERMANENT · MAX LEVEL 5</small></div>
            {upgradeInfo.map((item) => {
              const level = upgrades[item.key]; const cost = upgradeCost(level, CHARACTERS.indexOf(preview));
              return <button key={item.key} className="upgrade-row" onClick={() => onUpgrade(item.key)} disabled={!unlocked || level >= 5}>
                <span className="upgrade-icon">{item.icon}</span><span><strong>{item.name}</strong><small>{item.description}</small><i className="level-pips">{[0, 1, 2, 3, 4].map((n) => <b key={n} className={n < level ? 'filled' : ''} />)}</i></span><em>{level >= 5 ? 'MAX' : <>{number(cost)} <Coins size={13} /></>}</em>
              </button>;
            })}
          </div>
        </aside>
      </div>
    </section>
  );
}

function ArmoryScreen({ save, onBack, onAction }: { save: SaveData; onBack: () => void; onAction: (id: WeaponId) => void }) {
  return <section className="sub-screen armory-screen"><ScreenHeader title="ARCANE ARMORY" subtitle="Six weapons. Six distinct ways to break a guardian." coins={save.coins} onBack={onBack} />
    <div className="armory-intro"><Swords size={26} /><div><strong>YOUR LOADOUT FOLLOWS YOU INTO EVERY REALM</strong><p>Tap the weapon-swap control during a run, or press Q, to cycle through owned weapons without pausing.</p></div></div>
    <div className="weapon-grid">{WEAPONS.map((item, index) => {
      const owned = save.unlockedWeapons.includes(item.id); const selected = save.selectedWeapon === item.id;
      return <article className={cx('weapon-card', selected && 'selected')} key={item.id} style={{ '--weapon-color': item.color } as React.CSSProperties}>
        <div className="weapon-visual"><span className="weapon-orbit" /><span className="weapon-orbit second" /><WeaponGlyph id={item.id} size={64} /><small>0{index + 1}</small></div>
        <div className="weapon-copy"><small>ARCANE WEAPON · TIER {Math.ceil((index + 1) / 2)}</small><h3>{item.name}</h3><p>{item.description}</p><div className="weapon-mechanic"><Crosshair size={14} />{item.mechanic}</div>
          <div className="weapon-stats"><span>DAMAGE <b>{item.damage}</b></span><span>RATE <b>{(1 / item.cooldown).toFixed(1)}/s</b></span><span>VELOCITY <b>{item.projectileSpeed}</b></span></div>
          <button className="wide-action" onClick={() => onAction(item.id)} disabled={selected}>{selected ? <><Check size={17} /> EQUIPPED</> : owned ? <><Sword size={17} /> EQUIP WEAPON</> : <><Lock size={17} /> FORGE · {number(item.cost)} <Coins size={15} /></>}</button>
        </div>
      </article>;
    })}</div>
  </section>;
}

function RecordsScreen({ save, onBack }: { save: SaveData; onBack: () => void }) {
  return <section className="sub-screen records-screen"><ScreenHeader title="HUNTER'S LEGACY" subtitle="Local records and feats from every hunt." coins={save.coins} onBack={onBack} />
    <div className="record-summary"><div><Trophy size={23} /><strong>{number(save.bestScore)}</strong><small>HIGH SCORE</small></div><div><Map size={23} /><strong>{number(save.bestDistance)} m</strong><small>BEST DISTANCE</small></div><div><Skull size={23} /><strong>{number(save.bossesDefeated)}</strong><small>BOSSES DEFEATED</small></div><div><Activity size={23} /><strong>{number(save.totalRuns)}</strong><small>TOTAL RUNS</small></div><div><Coins size={23} /><strong>{number(save.totalCoins)}</strong><small>LIFETIME COINS</small></div></div>
    <div className="section-label"><span>ACHIEVEMENTS</span><small>{save.achievements.length} / {ACHIEVEMENTS.length} UNLOCKED</small></div>
    <div className="achievement-grid">{ACHIEVEMENTS.map((item) => {
      const unlocked = save.achievements.includes(item.id);
      return <article className={cx('achievement-card', unlocked && 'unlocked')} key={item.id}><div className="achievement-medal">{unlocked ? <Award size={25} /> : <Lock size={21} />}</div><div><small>{unlocked ? 'FEAT COMPLETED' : 'UNCHARTED FEAT'}</small><h3>{item.name}</h3><p>{item.description}</p></div><span>{unlocked ? <CheckCircle2 size={18} /> : <>{item.reward} <Coins size={13} /></>}</span></article>;
    })}</div>
    <p className="local-note"><ShieldCheck size={15} /> Progress is stored locally on this device. No account or network connection is required.</p>
  </section>;
}

function SettingsScreen({ save, onBack, onChange, onReset, onGuide }: { save: SaveData; onBack: () => void; onChange: <K extends keyof SaveSettings>(key: K, value: SaveSettings[K]) => void; onReset: () => void; onGuide: () => void }) {
  const quality: Array<{ id: GraphicsQuality; name: string; description: string }> = [
    { id: 'low', name: 'Low', description: '1× rendering · no shadows · reduced particles' },
    { id: 'medium', name: 'Medium', description: 'Balanced shadows, scenery and resolution' },
    { id: 'high', name: 'High', description: 'Soft shadows · dense scenery · full effects' },
  ];
  return <section className="sub-screen settings-screen"><ScreenHeader title="SETTINGS" subtitle="Tune the hunt for your device." onBack={onBack} />
    <div className="settings-layout"><div className="settings-main">
      <section className="setting-panel"><div className="setting-title"><Gauge size={20} /><div><h3>GRAPHICS QUALITY</h3><p>Applied at the beginning of the next run.</p></div></div><div className="quality-options">{quality.map((item) => <button key={item.id} className={save.settings.graphics === item.id ? 'active' : ''} onClick={() => onChange('graphics', item.id)}><span>{save.settings.graphics === item.id ? <CheckCircle2 size={18} /> : <Circle size={18} />}</span><strong>{item.name}</strong><small>{item.description}</small></button>)}</div></section>
      <section className="setting-panel"><div className="setting-title"><Volume2 size={20} /><div><h3>AUDIO MIX</h3><p>Procedural music and real-time combat effects.</p></div></div>
        <label className="slider-row"><Music size={18} /><span>Music</span><input type="range" min="0" max="1" step="0.05" value={save.settings.music} onChange={(e) => onChange('music', Number(e.target.value))} /><b>{Math.round(save.settings.music * 100)}%</b></label>
        <label className="slider-row"><Volume2 size={18} /><span>Effects</span><input type="range" min="0" max="1" step="0.05" value={save.settings.sfx} onChange={(e) => onChange('sfx', Number(e.target.value))} /><b>{Math.round(save.settings.sfx * 100)}%</b></label>
      </section>
      <section className="setting-panel"><div className="setting-title"><Smartphone size={20} /><div><h3>CONTROLS & COMFORT</h3><p>Touch and camera preferences.</p></div></div>
        <ToggleRow icon={<Vibrate size={18} />} title="Haptic feedback" description="Vibrate on supported Android devices" value={save.settings.haptics} onChange={(v) => onChange('haptics', v)} />
        <ToggleRow icon={<Camera size={18} />} title="Camera shake" description="Impact and boss cinematic movement" value={save.settings.cameraShake} onChange={(v) => onChange('cameraShake', v)} />
        <ToggleRow icon={<Hand size={18} />} title="Left-handed controls" description="Swap combat and movement clusters" value={save.settings.leftHanded} onChange={(v) => onChange('leftHanded', v)} />
      </section>
    </div><aside className="settings-side"><div className="device-card"><Smartphone size={34} /><small>MOBILE BUILD</small><h3>ANDROID READY</h3><p>Install the web build with Capacitor for a native fullscreen Android package. Swipe, safe areas, haptics, quality scaling and local saves are built in.</p><button className="wide-action" onClick={onGuide}><Download size={17} /> VIEW BUILD INSTRUCTIONS</button></div>
      <div className="device-card compact"><Info size={22} /><h3>PERFORMANCE TIP</h3><p>On older phones, choose Low and keep device battery-saving mode off. The simulation caps long frame steps to preserve collision reliability.</p></div>
      <button className="danger-button" onClick={onReset}><RotateCcw size={16} /> RESET LOCAL PROGRESS</button>
    </aside></div>
  </section>;
}

function ToggleRow({ icon, title, description, value, onChange }: { icon: ReactNode; title: string; description: string; value: boolean; onChange: (value: boolean) => void }) {
  return <button className="toggle-row" onClick={() => onChange(!value)} role="switch" aria-checked={value}>{icon}<span><strong>{title}</strong><small>{description}</small></span><i className={value ? 'on' : ''}><b /></i></button>;
}

function GuideScreen({ onBack }: { onBack: () => void }) {
  const traps = [
    ['Fire, spikes & collapsing bridges', 'Jump', <ArrowUp size={16} />],
    ['Blades, lasers & electric barriers', 'Slide', <ArrowDown size={16} />],
    ['Walls, falling rocks & arcane barrages', 'Change lane', <ArrowLeft size={16} />],
    ['Boss shockwaves and sweeping beams', 'Read the red telegraph', <Crosshair size={16} />],
  ];
  return <section className="sub-screen guide-screen"><ScreenHeader title="FIELD GUIDE" subtitle="Everything you need to survive the hunt." onBack={onBack} />
    <div className="guide-grid"><section className="guide-panel"><div className="setting-title"><Hand size={21} /><div><h3>TOUCH CONTROLS</h3><p>Direct gestures anywhere on the 3D view.</p></div></div><div className="gesture-grid"><div><ArrowLeft size={25} /><strong>Swipe left</strong><small>Move one lane left</small></div><div><ArrowRight size={25} /><strong>Swipe right</strong><small>Move one lane right</small></div><div><ArrowUp size={25} /><strong>Swipe up</strong><small>Jump over traps</small></div><div><ArrowDown size={25} /><strong>Swipe down</strong><small>Slide under attacks</small></div><div><Sword size={25} /><strong>Tap / Strike</strong><small>Fire equipped weapon</small></div><div><Sparkles size={25} /><strong>Ability rune</strong><small>Use signature power</small></div></div><p className="keyboard-note"><Keyboard size={17} /> Keyboard: A/D or arrows move · Space jumps · S slides · F attacks · E ability · Q swaps · P pauses.</p></section>
      <section className="guide-panel"><div className="setting-title"><Crosshair size={21} /><div><h3>SURVIVAL RULES</h3><p>Every hazard has a physical counter.</p></div></div><div className="trap-list">{traps.map(([name, action, icon]) => <div key={String(name)}><span>{icon}</span><p>{name}</p><strong>{action}</strong></div>)}</div><div className="guide-callout"><Skull size={21} /><p>Obstacle hits let the assassin close the gap. At <b>every 100 m</b>, it summons a staged guardian. Attack its core while reading telegraphs; later realms add faster patterns and more health.</p></div></section>
      <section className="guide-panel wide"><div className="setting-title"><Gem size={21} /><div><h3>POWER-UP MATRIX</h3><p>Pickups spawn along living routes and during guardian battles.</p></div></div><div className="powerup-guide">{(Object.keys(POWERUPS) as PowerupType[]).map((id) => <div key={id} style={{ '--power': POWERUPS[id].color } as React.CSSProperties}><PowerupGlyph type={id} size={22} /><strong>{POWERUPS[id].name}</strong><p>{POWERUPS[id].description}</p><small>{POWERUPS[id].duration ? `${POWERUPS[id].duration} seconds` : 'Instant / charge'}</small></div>)}</div></section>
      <section className="guide-panel wide android-guide"><div className="setting-title"><Smartphone size={21} /><div><h3>BUILD & RUN ON ANDROID</h3><p>Three.js + Vite web game, wrapped natively with Capacitor.</p></div></div><ol><li><b>Web:</b> install Node.js 20+, run <code>npm install</code>, then <code>npm run dev</code>. Open the shown local address on your phone or desktop.</li><li><b>Production:</b> run <code>npm run build</code>. The optimized game is generated in <code>dist/</code>.</li><li><b>Native shell:</b> run <code>npm install @capacitor/core @capacitor/cli @capacitor/android</code>, then <code>npx cap init "Shadow Run" com.nightfall.shadowrun --web-dir=dist</code> and <code>npx cap add android</code>.</li><li><b>Build APK/AAB:</b> after each web build run <code>npx cap sync android</code>, then <code>npx cap open android</code>. In Android Studio select a device and Run, or use Build → Generate Signed Bundle / APK for release.</li></ol><p><Info size={15} /> Recommended: Android 8+, a WebGL2-capable WebView, landscape or portrait orientation. Source structure: <code>src/game/</code> simulation/content/audio/saves, <code>src/App.tsx</code> UI, <code>public/</code> media.</p></section>
    </div>
  </section>;
}

function GameHUD({ snapshot, character, weapon, paused, onPause, engine }: { snapshot: GameSnapshot; character: CharacterDef; weapon: ReturnType<typeof getWeapon>; paused: boolean; onPause: () => void; engine: React.RefObject<ShadowRunEngine | null> }) {
  const abilityPercent = snapshot.abilityTotal ? Math.min(100, (snapshot.abilityCooldown / snapshot.abilityTotal) * 100) : 0;
  return <div className={cx('hud', paused && 'hud-paused')}>
    <div className="hud-top"><div className="distance-block"><small>DISTANCE</small><strong>{number(snapshot.distance)}<em>m</em></strong><span><Map size={12} /> {snapshot.biome}</span></div>
      <div className="hud-score"><small>SCORE</small><strong>{number(snapshot.score)}</strong>{snapshot.combo > 2 && <span>FLOW ×{snapshot.combo}</span>}</div>
      <div className="hud-currency"><CoinBalance coins={snapshot.coins} /><IconButton label="Pause" onClick={onPause}><Pause size={20} /></IconButton></div></div>
    <div className="health-block"><div className="health-hearts">{Array.from({ length: snapshot.maxHealth }).map((_, index) => <Heart key={index} size={19} fill={index < snapshot.health ? 'currentColor' : 'none'} className={index < snapshot.health ? 'alive' : 'lost'} />)}</div>{snapshot.shield > 0 && <span className="shield-count"><Shield size={14} fill="currentColor" /> {snapshot.shield}</span>}</div>
    <div className={cx('assassin-meter', snapshot.threat > 0.65 && 'critical')}><div><Skull size={15} /><span>ASSASSIN PROXIMITY</span><b>{snapshot.threat > 0.78 ? 'LETHAL' : snapshot.threat > 0.5 ? 'CLOSING' : 'HUNTING'}</b></div><i><span style={{ width: `${snapshot.threat * 100}%` }} /></i></div>
    {snapshot.boss && !snapshot.boss.intro && <div className="boss-hud"><div><small>GUARDIAN · PHASE {snapshot.boss.phase}</small><strong>{snapshot.boss.name}</strong><span>{Math.ceil(snapshot.boss.hp)} / {snapshot.boss.maxHp}</span></div><i><span style={{ width: `${Math.max(0, snapshot.boss.hp / snapshot.boss.maxHp) * 100}%` }} /></i>{snapshot.boss.attack && <b className="boss-attack"><Crosshair size={14} /> {snapshot.boss.attack.toUpperCase()} INCOMING</b>}</div>}
    {snapshot.assassinAttack && <div className="hex-warning"><Skull size={17} /> SHADOW HEX · EVADE</div>}
    <div className="active-powerups">{Object.entries(snapshot.powerups).map(([type, time]) => <div key={type} style={{ '--power': POWERUPS[type as PowerupType].color } as React.CSSProperties}><PowerupGlyph type={type as PowerupType} /><span>{POWERUPS[type as PowerupType].name}</span><b>{Math.ceil(time ?? 0)}s</b></div>)}</div>
    <div className="touch-controls">
      <div className="movement-cluster"><div><button aria-label="Move left" onPointerDown={(e) => { e.stopPropagation(); engine.current?.move(-1); }}><ArrowLeft size={26} /></button><button aria-label="Move right" onPointerDown={(e) => { e.stopPropagation(); engine.current?.move(1); }}><ArrowRight size={26} /></button></div><div><button aria-label="Jump" onPointerDown={(e) => { e.stopPropagation(); engine.current?.jump(); }}><ArrowUp size={25} /><small>JUMP</small></button><button aria-label="Slide" onPointerDown={(e) => { e.stopPropagation(); engine.current?.slide(); }}><ArrowDown size={25} /><small>SLIDE</small></button></div></div>
      <div className="combat-cluster"><button className="weapon-swap" aria-label="Swap weapon" onPointerDown={(e) => { e.stopPropagation(); engine.current?.cycleWeapon(); }}><RotateCcw size={15} /><span>SWAP</span></button><button className="ability-button" aria-label={`Use ${character.ability.name}`} onPointerDown={(e) => { e.stopPropagation(); engine.current?.useAbility(); }} style={{ '--cooldown': `${abilityPercent * 3.6}deg`, '--ability-color': character.colors.accent } as React.CSSProperties}><div><Sparkles size={25} />{snapshot.abilityCooldown > 0 && <strong>{Math.ceil(snapshot.abilityCooldown)}</strong>}</div><span>{snapshot.abilityCooldown > 0 ? 'RECHARGING' : character.ability.name.split(' ')[0].toUpperCase()}</span></button><button className="attack-button" aria-label={`Attack with ${weapon.name}`} onPointerDown={(e) => { e.stopPropagation(); engine.current?.attack(); }} style={{ '--weapon-color': weapon.color } as React.CSSProperties}><WeaponGlyph id={weapon.id} size={32} /><span>STRIKE</span><small>{weapon.name}</small></button></div>
    </div>
    <div className="desktop-hint">A D MOVE · SPACE JUMP · S SLIDE · F STRIKE · E ABILITY</div>
  </div>;
}

function BossIntro({ snapshot }: { snapshot: GameSnapshot }) {
  if (!snapshot.boss) return null;
  return <div className="boss-intro"><div className="cinematic-bar top" /><div className="boss-intro-copy"><small><Skull size={16} /> {Math.floor(snapshot.distance / 100) * 100} M GUARDIAN</small><h2>{snapshot.boss.name}</h2><p>{snapshot.boss.title}</p><div><span /> ASSASSIN'S CHOSEN <span /></div></div><div className="cinematic-bar bottom" /></div>;
}

function PauseMenu({ save, onResume, onRestart, onEnd, onVolume }: { save: SaveData; onResume: () => void; onRestart: () => void; onEnd: () => void; onVolume: <K extends keyof SaveSettings>(key: K, value: SaveSettings[K]) => void }) {
  return <div className="modal-layer"><div className="pause-panel"><small>THE HUNT IS SUSPENDED</small><h2>PAUSED</h2><p>{getCharacter(save.selectedCharacter).name} · {getWeapon(save.selectedWeapon).name}</p><button className="primary-cta compact" onClick={onResume}><Play size={20} fill="currentColor" /><span>RESUME RUN</span></button><button className="wide-action" onClick={onRestart}><RotateCcw size={17} /> RESTART</button><div className="pause-volume"><label><Music size={16} /><input aria-label="Music volume" type="range" min="0" max="1" step=".05" value={save.settings.music} onChange={(e) => onVolume('music', Number(e.target.value))} /></label><label><Volume2 size={16} /><input aria-label="Effects volume" type="range" min="0" max="1" step=".05" value={save.settings.sfx} onChange={(e) => onVolume('sfx', Number(e.target.value))} /></label></div><button className="text-button" onClick={onEnd}>END RUN & COLLECT COINS</button><small className="pause-tip">Press P or Esc to resume</small></div></div>;
}

function GameOver({ result, save, achievements, onRestart, onMenu }: { result: RunResult; save: SaveData; achievements: string[]; onRestart: () => void; onMenu: () => void }) {
  const isBest = Math.round(result.score) >= save.bestScore && result.score > 0;
  return <div className="modal-layer gameover-layer"><div className="gameover-panel"><div className="gameover-sigil"><Skull size={31} /></div><small>THE HUNT HAS ENDED</small><h2>{result.cause === 'Claimed by the Assassin' ? 'CLAIMED BY SHADOW' : 'RUN COMPLETE'}</h2><p>{result.cause}</p>{isBest && <div className="new-best"><Crown size={16} /> PERSONAL BEST</div>}
    <div className="result-grid"><div><small>DISTANCE</small><strong>{number(result.distance)}<em>m</em></strong></div><div><small>FINAL SCORE</small><strong>{number(result.score)}</strong></div><div><small>COINS RECOVERED</small><strong className="gold">+{number(result.coins)} <Coins size={20} /></strong></div><div><small>GUARDIANS</small><strong>{result.bosses}</strong></div></div>
    {achievements.length > 0 && <div className="run-achievements"><Award size={19} /><div><small>NEW ACHIEVEMENT{achievements.length > 1 ? 'S' : ''}</small>{achievements.map((id) => <strong key={id}>{ACHIEVEMENTS.find((a) => a.id === id)?.name}</strong>)}</div></div>}
    <div className="gameover-actions"><button className="primary-cta compact" onClick={onRestart}><RotateCcw size={20} /><span>RUN AGAIN</span></button><button className="wide-action" onClick={onMenu}><Home size={18} /> MAIN MENU</button></div><small className="saved-note"><CheckCircle2 size={13} /> Progress saved locally</small></div></div>;
}
