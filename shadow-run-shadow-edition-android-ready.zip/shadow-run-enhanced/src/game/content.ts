export type CharacterId =
  | 'kael' | 'lyra' | 'ember' | 'thorne' | 'nyx'
  | 'sora' | 'vex' | 'mira' | 'ronan' | 'zephyr';

export type WeaponId = 'fireSword' | 'iceStaff' | 'thunderBlade' | 'shadowDaggers' | 'energyBow' | 'phoenixOrb';
export type BiomeId = 'forest' | 'temple' | 'castle' | 'city' | 'mountains';
export type GraphicsQuality = 'low' | 'medium' | 'high';
export type ObstacleType = 'fire' | 'blade' | 'spikes' | 'bridge' | 'rock' | 'electric' | 'wall' | 'laser' | 'magic';
export type PowerupType = 'boost' | 'shield' | 'magnet' | 'jump' | 'heal' | 'invincible';

export interface CharacterDef {
  id: CharacterId;
  name: string;
  title: string;
  cost: number;
  lore: string;
  perk: string;
  colors: { primary: string; secondary: string; accent: string; skin: string };
  model: 'hood' | 'crown' | 'mohawk' | 'horns' | 'veil' | 'phoenix' | 'topknot' | 'ribbons' | 'helm' | 'void';
  stats: { health: number; speed: number; power: number };
  ability: { name: string; description: string; cooldown: number };
}

export const CHARACTERS: CharacterDef[] = [
  {
    id: 'kael', name: 'Kael', title: 'The Nightrunner', cost: 0,
    lore: 'The last oathblade of a fallen order, bound to outrun the shadow wearing his face.',
    perk: 'Double assassin recovery after a clean dodge',
    colors: { primary: '#182331', secondary: '#394b5e', accent: '#65e6ff', skin: '#b8876e' }, model: 'hood',
    stats: { health: 3, speed: 1, power: 1 },
    ability: { name: 'Shadow Dash', description: 'Become untouchable, destroy nearby traps, and throw the assassin back.', cooldown: 18 },
  },
  {
    id: 'lyra', name: 'Lyra', title: 'Frostborn Oracle', cost: 900,
    lore: 'An exile who hears tomorrow in the cracking of ancient ice.',
    perk: 'Ice effects last 30% longer; begins with a shield',
    colors: { primary: '#c5e8ed', secondary: '#477b9b', accent: '#a8f3ff', skin: '#d8b7a4' }, model: 'crown',
    stats: { health: 3, speed: 0.96, power: 1.08 },
    ability: { name: 'Glacial Stillness', description: 'Freeze hazards and bosses, then shatter traps around you.', cooldown: 22 },
  },
  {
    id: 'ember', name: 'Ember', title: 'Ashblade Rogue', cost: 1500,
    lore: 'A smiling wildfire with a phoenix feather hidden beneath her cuirass.',
    perk: 'Weapon hits have a 20% chance to burn for bonus damage',
    colors: { primary: '#511f24', secondary: '#a43d25', accent: '#ffb13b', skin: '#9f604b' }, model: 'mohawk',
    stats: { health: 3, speed: 1.04, power: 1.12 },
    ability: { name: 'Inferno Rush', description: 'Unleash automatic fire crescents and scorch every trap in your path.', cooldown: 24 },
  },
  {
    id: 'thorne', name: 'Thorne', title: 'Oathstone Guardian', cost: 2200,
    lore: 'A living bulwark carved from the foundation of the first temple.',
    perk: '+1 maximum health; obstacle impacts push the assassin less',
    colors: { primary: '#323a35', secondary: '#6c745b', accent: '#b6d779', skin: '#7d7668' }, model: 'horns',
    stats: { health: 4, speed: 0.9, power: 1.05 },
    ability: { name: 'Oathstone Ward', description: 'Gain three shield charges and force the pursuing shadow backward.', cooldown: 25 },
  },
  {
    id: 'nyx', name: 'Nyx', title: 'Hourless Witch', cost: 3000,
    lore: 'She stole a minute from death and has been spending it ever since.',
    perk: 'All ability cooldowns recover 12% faster',
    colors: { primary: '#251b43', secondary: '#68429a', accent: '#e2a5ff', skin: '#b78781' }, model: 'veil',
    stats: { health: 3, speed: 1.02, power: 1.04 },
    ability: { name: 'Time Fracture', description: 'Slow the world and hostile attacks while your movement stays swift.', cooldown: 26 },
  },
  {
    id: 'sora', name: 'Sora', title: 'Phoenix Vessel', cost: 3900,
    lore: 'A temple dancer carrying the final warm heartbeat of a sunbird.',
    perk: 'Healing power-ups also grant a brief shield',
    colors: { primary: '#efe0b8', secondary: '#b64f37', accent: '#ffd76a', skin: '#c68f6a' }, model: 'phoenix',
    stats: { health: 3, speed: 1, power: 1.08 },
    ability: { name: 'Phoenix Soul', description: 'Restore health and rise again from one lethal hit for twelve seconds.', cooldown: 30 },
  },
  {
    id: 'vex', name: 'Vex', title: 'Stormblade Exile', cost: 4800,
    lore: 'A arena champion who caught lightning and refused to give it back.',
    perk: 'Every fifth hit releases free chain lightning',
    colors: { primary: '#172f42', secondary: '#296c87', accent: '#8df6ff', skin: '#6f463c' }, model: 'topknot',
    stats: { health: 3, speed: 1.08, power: 1.1 },
    ability: { name: 'Storm Verdict', description: 'Call down devastating chain lightning on the boss and every active trap.', cooldown: 23 },
  },
  {
    id: 'mira', name: 'Mira', title: 'Gilded Whisper', cost: 5800,
    lore: 'A royal thief whose footsteps only exist when nobody is listening.',
    perk: '+15% coin value and a wider collection radius',
    colors: { primary: '#402642', secondary: '#9b526b', accent: '#ffd990', skin: '#b87858' }, model: 'ribbons',
    stats: { health: 3, speed: 1.06, power: 0.98 },
    ability: { name: 'Gilded Siren', description: 'Double coin values and draw every coin on the road toward you.', cooldown: 20 },
  },
  {
    id: 'ronan', name: 'Ronan', title: 'The Skybreaker', cost: 6900,
    lore: 'A mountain siege-breaker who learned that no chain survives a hard enough landing.',
    perk: 'Higher jumps and hard landings destroy ground traps',
    colors: { primary: '#34312d', secondary: '#795439', accent: '#ffcb79', skin: '#a46f50' }, model: 'helm',
    stats: { health: 4, speed: 0.94, power: 1.16 },
    ability: { name: 'Titan Ascension', description: 'Launch into a super jump; the landing shockwave crushes nearby hazards.', cooldown: 21 },
  },
  {
    id: 'zephyr', name: 'Zephyr', title: 'Herald of the Void', cost: 8200,
    lore: 'The only soul to escape the assassin’s realm—and the reason it learned to hunt.',
    perk: '+20% boss damage; assassin encounters begin farther away',
    colors: { primary: '#101018', secondary: '#3a285c', accent: '#b58aff', skin: '#9a8ca6' }, model: 'void',
    stats: { health: 3, speed: 1.1, power: 1.2 },
    ability: { name: 'Event Horizon', description: 'Open a void that erases every trap, wounds the boss, and grants invincibility.', cooldown: 28 },
  },
];

export interface WeaponDef {
  id: WeaponId;
  name: string;
  cost: number;
  color: string;
  damage: number;
  cooldown: number;
  projectileSpeed: number;
  mechanic: string;
  description: string;
}

export const WEAPONS: WeaponDef[] = [
  { id: 'fireSword', name: 'Fire Sword', cost: 0, color: '#ff7138', damage: 18, cooldown: 0.48, projectileSpeed: 35, mechanic: 'Wide burning crescent · splash damage', description: 'Balanced arcane blade. Its flame crescents explode on impact and can burn bosses.' },
  { id: 'iceStaff', name: 'Ice Staff', cost: 800, color: '#8deaff', damage: 15, cooldown: 0.55, projectileSpeed: 30, mechanic: 'Slows boss attack charge by 25%', description: 'Launches seeking frost shards. Repeated hits delay hostile attack patterns.' },
  { id: 'thunderBlade', name: 'Thunder Blade', cost: 1500, color: '#b9a0ff', damage: 13, cooldown: 0.68, projectileSpeed: 90, mechanic: 'Instant chain strike · hits up to 3 traps', description: 'Lightning arrives instantly, chaining through nearby hazards before striking its target.' },
  { id: 'shadowDaggers', name: 'Shadow Daggers', cost: 2300, color: '#d285ff', damage: 9, cooldown: 0.34, projectileSpeed: 42, mechanic: 'Three-dagger fan · high close damage', description: 'Throws a spectral fan. All three blades can strike large bosses for rapid burst damage.' },
  { id: 'energyBow', name: 'Energy Bow', cost: 3200, color: '#6effc1', damage: 27, cooldown: 0.82, projectileSpeed: 58, mechanic: 'Piercing arrow · critical weak-point hits', description: 'A long-range piercing bolt. Shots fired during a boss telegraph deal critical damage.' },
  { id: 'phoenixOrb', name: 'Phoenix Orb', cost: 4500, color: '#ffcc62', damage: 34, cooldown: 1.05, projectileSpeed: 25, mechanic: 'Explodes · restores health on boss defeat', description: 'A slow sunfire orb with a huge blast. Boss kills with it restore one health.' },
];

export interface BossDef {
  name: string;
  title: string;
  color: string;
  accent: string;
  shape: 'treant' | 'idol' | 'knight' | 'colossus' | 'revenant';
  attacks: Array<'slam' | 'wave' | 'barrage' | 'beam' | 'storm' | 'drain'>;
}

export interface BiomeDef {
  id: BiomeId;
  name: string;
  subtitle: string;
  sky: string;
  fog: string;
  ground: string;
  edge: string;
  accent: string;
  sun: string;
  particle: 'fireflies' | 'dust' | 'souls' | 'embers' | 'snow';
  obstacles: ObstacleType[];
  boss: BossDef;
}

export const BIOMES: BiomeDef[] = [
  {
    id: 'forest', name: 'Haunted Forest', subtitle: 'Where the roots remember', sky: '#071615', fog: '#102b28', ground: '#172a25', edge: '#2b4438', accent: '#6de2b0', sun: '#92c9b0', particle: 'fireflies',
    obstacles: ['spikes', 'fire', 'blade', 'rock', 'bridge', 'magic'],
    boss: { name: 'MALGOR, ROOT OF RUIN', title: 'The Thorn Warden', color: '#294838', accent: '#8cff9b', shape: 'treant', attacks: ['slam', 'barrage', 'wave'] },
  },
  {
    id: 'temple', name: 'Ancient Temple', subtitle: 'The sun has forgotten this place', sky: '#21160e', fog: '#4b3520', ground: '#50432f', edge: '#8a7145', accent: '#ffc86a', sun: '#ffd599', particle: 'dust',
    obstacles: ['blade', 'wall', 'laser', 'bridge', 'spikes', 'rock'],
    boss: { name: 'SEKHAR, THE HOLLOW SUN', title: 'Idol of the Last Dynasty', color: '#75603b', accent: '#ffcf67', shape: 'idol', attacks: ['beam', 'slam', 'storm'] },
  },
  {
    id: 'castle', name: 'Dark Castle', subtitle: 'No candle burns without permission', sky: '#090916', fog: '#18152c', ground: '#262536', edge: '#444258', accent: '#b48cff', sun: '#a9a3d8', particle: 'souls',
    obstacles: ['electric', 'wall', 'laser', 'magic', 'blade', 'bridge'],
    boss: { name: 'SIR VAEL, DEATHLESS', title: 'The Dread Knight', color: '#302d49', accent: '#bb8cff', shape: 'knight', attacks: ['wave', 'beam', 'drain'] },
  },
  {
    id: 'city', name: 'Burning City', subtitle: 'Run beyond the final alarm', sky: '#250b0a', fog: '#552019', ground: '#392a29', edge: '#6b3b31', accent: '#ff7545', sun: '#ff9c65', particle: 'embers',
    obstacles: ['fire', 'rock', 'wall', 'electric', 'laser', 'bridge'],
    boss: { name: 'IGNIS, CITY-EATER', title: 'The Inferno Colossus', color: '#592c27', accent: '#ff7849', shape: 'colossus', attacks: ['storm', 'wave', 'barrage'] },
  },
  {
    id: 'mountains', name: 'Frozen Mountains', subtitle: 'Above the clouds, below zero', sky: '#0d1b2b', fog: '#9ab3c1', ground: '#aec4cb', edge: '#d8e5e7', accent: '#9ceaff', sun: '#d5f4ff', particle: 'snow',
    obstacles: ['spikes', 'rock', 'electric', 'magic', 'wall', 'bridge'],
    boss: { name: 'VASTRA, THE PALE END', title: 'Winter Revenant', color: '#8ca9b7', accent: '#b6f4ff', shape: 'revenant', attacks: ['beam', 'barrage', 'drain'] },
  },
];

export const POWERUPS: Record<PowerupType, { name: string; color: string; duration: number; description: string }> = {
  boost: { name: 'Wind Rush', color: '#63eaff', duration: 6, description: 'Faster run and score gain' },
  shield: { name: 'Aegis', color: '#74a7ff', duration: 0, description: 'Blocks one impact' },
  magnet: { name: 'Coin Magnet', color: '#ffcf5b', duration: 9, description: 'Draws nearby coins' },
  jump: { name: 'Griffin Step', color: '#a5ff88', duration: 9, description: 'Higher, longer jumps' },
  heal: { name: 'Lifebloom', color: '#ff7f9c', duration: 0, description: 'Restores one health' },
  invincible: { name: 'Star Veil', color: '#e4a1ff', duration: 5, description: 'Ignore all damage' },
};

export interface AchievementDef { id: string; name: string; description: string; reward: number }
export const ACHIEVEMENTS: AchievementDef[] = [
  { id: 'firstBlood', name: 'The Chase Begins', description: 'Complete your first run', reward: 100 },
  { id: 'century', name: 'One Hundred Steps', description: 'Defeat the 100 m guardian', reward: 150 },
  { id: 'bossSlayer', name: 'Breaker of Legends', description: 'Defeat five bosses in total', reward: 400 },
  { id: 'distance500', name: 'Beyond the Reach', description: 'Run 500 m in one run', reward: 300 },
  { id: 'distance1000', name: 'The Unassailable', description: 'Run 1,000 m in one run', reward: 750 },
  { id: 'coin500', name: 'Gilded Footsteps', description: 'Collect 500 coins across all runs', reward: 250 },
  { id: 'untouchable', name: 'Not a Single Scratch', description: 'Defeat a boss without taking damage in the encounter', reward: 350 },
  { id: 'threeHeroes', name: 'A Growing Rebellion', description: 'Unlock three characters', reward: 300 },
  { id: 'arsenal', name: 'Six Forms of Ruin', description: 'Own every magical weapon', reward: 600 },
  { id: 'ascended', name: 'Slayer of Ascended Gods', description: 'Defeat a boss beyond 500 m', reward: 1000 },
];

export const getCharacter = (id: CharacterId) => CHARACTERS.find((c) => c.id === id) ?? CHARACTERS[0];
export const getWeapon = (id: WeaponId) => WEAPONS.find((w) => w.id === id) ?? WEAPONS[0];
