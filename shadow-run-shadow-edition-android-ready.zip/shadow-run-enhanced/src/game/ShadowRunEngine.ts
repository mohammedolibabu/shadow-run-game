import * as THREE from 'three';
import {
  BIOMES, getCharacter, getWeapon, POWERUPS,
  type BiomeDef, type CharacterDef, type CharacterId, type GraphicsQuality, type ObstacleType,
  type PowerupType, type WeaponDef, type WeaponId,
} from './content';
import type { RunResult, Settings, UpgradeSet } from './save';
import type { GameAudio } from './audio';
import {
  createBoss, createCharacter, createCoin, createObstacle, createPowerup, createProjectile,
  createTrackSegment, createWeaponModel, type CharacterRig,
} from './visuals';

const LANES = [-2.35, 0, 2.35];
const PLAYER_Z = 0;
const TRACK_LENGTH = 12;
const TRACK_SEGMENTS = 14;

type EngineMode = 'playing' | 'paused' | 'over';

interface ObstacleEntity {
  group: THREE.Group;
  type: ObstacleType;
  lane: number;
  z: number;
  hit: boolean;
  passed: boolean;
  fromBoss: boolean;
  phase: number;
  hp: number;
}

interface CoinEntity { group: THREE.Group; x: number; y: number; z: number; collected: boolean }
interface PowerupEntity { group: THREE.Group; type: PowerupType; x: number; z: number }
interface ProjectileEntity {
  group: THREE.Group;
  weapon: WeaponDef;
  damage: number;
  vx: number;
  speed: number;
  life: number;
  pierce: number;
  radius: number;
}
interface BurstParticle { mesh: THREE.Mesh; velocity: THREE.Vector3; life: number; maxLife: number }
interface Warning { mesh: THREE.Mesh; life: number; maxLife: number }
interface BossEntity {
  rig: ReturnType<typeof createBoss>;
  hp: number;
  maxHp: number;
  phase: number;
  index: number;
  name: string;
  title: string;
  attackTimer: number;
  telegraph: number;
  attack: string;
  intro: number;
  slow: number;
  targetX: number;
  targetLane: number;
  safeLane: number;
  hitFlash: number;
}

export interface BossSnapshot {
  name: string;
  title: string;
  hp: number;
  maxHp: number;
  phase: number;
  attack: string;
  intro: boolean;
}

export interface GameSnapshot {
  distance: number;
  score: number;
  coins: number;
  health: number;
  maxHealth: number;
  shield: number;
  threat: number;
  combo: number;
  biome: string;
  biomeIndex: number;
  weapon: WeaponId;
  abilityCooldown: number;
  abilityTotal: number;
  boss: BossSnapshot | null;
  powerups: Partial<Record<PowerupType, number>>;
  speed: number;
  assassinAttack: boolean;
}

interface EngineOptions {
  container: HTMLElement;
  characterId: CharacterId;
  weaponId: WeaponId;
  unlockedWeapons: WeaponId[];
  upgrades: UpgradeSet;
  settings: Settings;
  audio: GameAudio;
  onSnapshot: (snapshot: GameSnapshot) => void;
  onGameOver: (result: RunResult) => void;
  onToast: (text: string, tone?: 'info' | 'danger' | 'reward') => void;
  onPauseRequest: () => void;
}

export class ShadowRunEngine {
  private options: EngineOptions;
  private renderer: THREE.WebGLRenderer;
  private scene = new THREE.Scene();
  private camera = new THREE.PerspectiveCamera(61, 1, 0.1, 180);
  private player!: CharacterRig;
  private assassin!: CharacterRig;
  private character: CharacterDef;
  private weapon: WeaponDef;
  private biomeIndex = 0;
  private biome: BiomeDef = BIOMES[0];
  private hemi = new THREE.HemisphereLight(0xb9d9d4, 0x17201d, 1.3);
  private sun = new THREE.DirectionalLight(0xffffff, 2.1);
  private rim = new THREE.PointLight(0x6de2b0, 7, 18, 2);
  private track: THREE.Group[] = [];
  private world = new THREE.Group();
  private entityLayer = new THREE.Group();
  private obstacles: ObstacleEntity[] = [];
  private coins: CoinEntity[] = [];
  private powerups: PowerupEntity[] = [];
  private projectiles: ProjectileEntity[] = [];
  private particles: BurstParticle[] = [];
  private warnings: Warning[] = [];
  private boss: BossEntity | null = null;
  private ambientPoints?: THREE.Points;
  private ambientPositions?: Float32Array;
  private frame = 0;
  private lastTime = 0;
  private elapsed = 0;
  private snapshotTimer = 0;
  private mode: EngineMode = 'playing';
  private disposed = false;
  private lane = 1;
  private playerY = 0;
  private verticalVelocity = 0;
  private grounded = true;
  private slideTimer = 0;
  private attackAnimation = 0;
  private hurtCooldown = 0;
  private distance = 0;
  private runCoins = 0;
  private scoreBonus = 0;
  private combo = 0;
  private health: number;
  private maxHealth: number;
  private shield = 0;
  private assassinGap: number;
  private assassinAttackTimer = 5;
  private assassinCharge = 0;
  private assassinTargetLane = 1;
  private abilityCooldown = 0;
  private abilityTotal: number;
  private weaponCooldown = 0;
  private spawnTimer = 1.4;
  private powerupTimer = 12;
  private nextBossAt = 100;
  private bossIndex = 0;
  private bossesDefeated = 0;
  private noHitBoss = false;
  private ascendedBossDefeated = false;
  private bossHurtPlayer = false;
  private reviveTimer = 0;
  private infernoTimer = 0;
  private infernoShot = 0;
  private slowTimer = 0;
  private freezeTimer = 0;
  private coinMultiplierTimer = 0;
  private weaponHits = 0;
  private shake = 0;
  private flashLight = 0;
  private timers: Record<'boost' | 'magnet' | 'jump' | 'invincible', number> = { boost: 0, magnet: 0, jump: 0, invincible: 0 };
  private pointerStart?: { x: number; y: number; time: number };
  private resizeObserver: ResizeObserver;
  private keyHandler = (event: KeyboardEvent) => this.onKey(event);
  private visibilityHandler = () => { if (document.hidden && this.mode === 'playing') this.options.onPauseRequest(); };

  constructor(options: EngineOptions) {
    this.options = options;
    this.character = getCharacter(options.characterId);
    this.weapon = getWeapon(options.weaponId);
    const vitality = options.upgrades.vitality;
    this.maxHealth = this.character.stats.health + Math.floor((vitality + 1) / 2);
    this.health = this.maxHealth;
    this.abilityTotal = this.getAbilityCooldown();
    this.assassinGap = this.character.id === 'zephyr' ? 11 : 9;
    this.shield = this.character.id === 'lyra' ? 1 : 0;

    this.renderer = new THREE.WebGLRenderer({ antialias: options.settings.graphics !== 'low', powerPreference: 'high-performance', alpha: false });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, options.settings.graphics === 'low' ? 1 : options.settings.graphics === 'medium' ? 1.35 : 1.8));
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 0.92;
    this.renderer.shadowMap.enabled = options.settings.graphics !== 'low';
    this.renderer.shadowMap.type = options.settings.graphics === 'high' ? THREE.PCFSoftShadowMap : THREE.PCFShadowMap;
    this.renderer.domElement.className = 'game-canvas';
    this.renderer.domElement.setAttribute('aria-label', 'Shadow Run 3D game. Swipe to move, jump and slide.');
    options.container.appendChild(this.renderer.domElement);

    this.scene.add(this.world, this.entityLayer);
    this.sun.position.set(-7, 13, 5);
    this.sun.castShadow = options.settings.graphics !== 'low';
    this.sun.shadow.mapSize.set(options.settings.graphics === 'high' ? 1024 : 512, options.settings.graphics === 'high' ? 1024 : 512);
    this.sun.shadow.camera.left = -10; this.sun.shadow.camera.right = 10;
    this.sun.shadow.camera.top = 12; this.sun.shadow.camera.bottom = -5;
    this.sun.shadow.camera.near = 1; this.sun.shadow.camera.far = 45;
    this.rim.position.set(0, 3, 2);
    this.scene.add(this.hemi, this.sun, this.rim);
    this.camera.position.set(0, 5.1, 10.8);

    this.player = createCharacter(this.character, this.weapon);
    this.assassin = createCharacter(this.character, this.weapon, true);
    this.player.group.position.set(0, 0, PLAYER_Z);
    this.assassin.group.position.set(0, 0, 6);
    this.scene.add(this.player.group, this.assassin.group);
    this.buildBiome(0);
    this.spawnCoinTrail(1, -15, 5);
    for (const lane of [0, 1, 2]) this.spawnObstacle('spikes', lane, -38);
    this.spawnCoinTrail(1, -41, 5, true);
    this.bindInput();
    this.resizeObserver = new ResizeObserver(() => this.resize());
    this.resizeObserver.observe(options.container);
    this.resize();
    window.addEventListener('keydown', this.keyHandler);
    document.addEventListener('visibilitychange', this.visibilityHandler);
    this.options.audio.setBiome(this.biome.id);
    this.options.audio.startMusic();
    this.options.onToast('SWIPE TO DODGE · TAP STRIKE TO ATTACK', 'info');
    this.frame = requestAnimationFrame((time) => this.loop(time));
  }

  private get quality(): GraphicsQuality { return this.options.settings.graphics; }
  private get score() { return Math.round(this.distance * 10 + this.runCoins * 18 + this.scoreBonus + this.combo * 4); }

  private buildBiome(index: number) {
    this.biomeIndex = ((index % BIOMES.length) + BIOMES.length) % BIOMES.length;
    this.biome = BIOMES[this.biomeIndex];
    for (const segment of this.track) { this.world.remove(segment); this.disposeObject(segment); }
    this.track = [];
    for (let i = 0; i < TRACK_SEGMENTS; i++) {
      const segment = createTrackSegment(this.biome, i, this.quality);
      segment.position.z = 12 - i * TRACK_LENGTH;
      this.world.add(segment); this.track.push(segment);
    }
    this.scene.background = new THREE.Color(this.biome.sky);
    this.scene.fog = new THREE.Fog(this.biome.fog, this.biome.id === 'mountains' ? 23 : 30, this.quality === 'low' ? 88 : 112);
    this.hemi.color.set(this.biome.sun); this.hemi.groundColor.set(this.biome.ground);
    this.sun.color.set(this.biome.sun); this.rim.color.set(this.biome.accent);
    this.sun.intensity = this.biome.id === 'castle' ? 1.5 : this.biome.id === 'city' ? 1.8 : 2.15;
    this.hemi.intensity = this.biome.id === 'mountains' ? 1.55 : 1.2;
    this.rim.intensity = this.biome.id === 'city' ? 5 : 7;
    this.createAmbientParticles();
    this.options.audio.setBiome(this.biome.id);
  }

  private createAmbientParticles() {
    if (this.ambientPoints) { this.scene.remove(this.ambientPoints); this.disposeObject(this.ambientPoints); }
    const count = this.quality === 'low' ? 45 : this.quality === 'medium' ? 100 : 180;
    const positions = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 25;
      positions[i * 3 + 1] = Math.random() * 10 + 0.3;
      positions[i * 3 + 2] = -Math.random() * 110 + 10;
    }
    const geometry = new THREE.BufferGeometry(); geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    const material = new THREE.PointsMaterial({
      color: this.biome.particle === 'snow' ? '#e8f7ff' : this.biome.particle === 'embers' ? '#ff793d' : this.biome.accent,
      size: this.biome.particle === 'snow' ? 0.1 : 0.075,
      transparent: true, opacity: this.biome.particle === 'dust' ? 0.35 : 0.68,
      depthWrite: false, blending: this.biome.particle === 'snow' || this.biome.particle === 'dust' ? THREE.NormalBlending : THREE.AdditiveBlending,
    });
    this.ambientPoints = new THREE.Points(geometry, material); this.ambientPositions = positions; this.scene.add(this.ambientPoints);
  }

  private bindInput() {
    const canvas = this.renderer.domElement;
    canvas.addEventListener('pointerdown', (event) => {
      this.pointerStart = { x: event.clientX, y: event.clientY, time: performance.now() };
      canvas.setPointerCapture(event.pointerId);
    });
    canvas.addEventListener('pointerup', (event) => {
      if (!this.pointerStart) return;
      const dx = event.clientX - this.pointerStart.x;
      const dy = event.clientY - this.pointerStart.y;
      const distance = Math.hypot(dx, dy);
      if (distance > 26) {
        if (Math.abs(dx) > Math.abs(dy)) this.move(dx > 0 ? 1 : -1);
        else if (dy < 0) this.jump(); else this.slide();
      } else if (performance.now() - this.pointerStart.time < 240) this.attack();
      this.pointerStart = undefined;
    });
    canvas.addEventListener('contextmenu', (event) => event.preventDefault());
  }

  private onKey(event: KeyboardEvent) {
    if (['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Space'].includes(event.code)) event.preventDefault();
    if ((event.code === 'Escape' || event.code === 'KeyP') && this.mode !== 'over') { this.options.onPauseRequest(); return; }
    if (this.mode !== 'playing') return;
    if (event.code === 'ArrowLeft' || event.code === 'KeyA') this.move(-1);
    if (event.code === 'ArrowRight' || event.code === 'KeyD') this.move(1);
    if (event.code === 'ArrowUp' || event.code === 'KeyW' || event.code === 'Space') this.jump();
    if (event.code === 'ArrowDown' || event.code === 'KeyS') this.slide();
    if (event.code === 'KeyF' || event.code === 'KeyJ') this.attack();
    if (event.code === 'KeyE' || event.code === 'KeyK') this.useAbility();
    if (event.code === 'KeyQ') this.cycleWeapon();
  }

  move(direction: number) {
    if (this.mode !== 'playing' || this.boss?.intro) return;
    const next = THREE.MathUtils.clamp(this.lane + direction, 0, 2);
    if (next !== this.lane) { this.lane = next; this.options.audio.sfx('select'); }
  }

  jump() {
    if (this.mode !== 'playing' || !this.grounded || this.slideTimer > 0.1 || this.boss?.intro) return;
    this.verticalVelocity = this.timers.jump > 0 || this.character.id === 'ronan' ? 11.3 : 8.8;
    this.grounded = false; this.slideTimer = 0; this.options.audio.sfx('jump');
  }

  slide() {
    if (this.mode !== 'playing' || !this.grounded || this.boss?.intro) return;
    this.slideTimer = 0.82; this.options.audio.sfx('slide');
  }

  attack() {
    if (this.mode !== 'playing' || this.weaponCooldown > 0 || this.boss?.intro) return;
    this.weaponCooldown = this.weapon.cooldown / (1 + this.options.upgrades.focus * 0.035);
    this.attackAnimation = 0.32;
    this.options.audio.sfx('attack', this.weapon.id);
    const power = this.character.stats.power * (1 + this.options.upgrades.focus * 0.025) * (this.character.id === 'zephyr' && this.boss ? 1.2 : 1);
    if (this.weapon.id === 'thunderBlade') {
      const targets = this.obstacles.filter((o) => !o.hit && o.z < -2 && o.z > -35).sort((a, b) => b.z - a.z).slice(0, 2);
      for (const target of targets) { this.createBurst(target.group.position, this.weapon.color, 5); this.removeObstacle(target, true); }
    }
    const spreads = this.weapon.id === 'shadowDaggers' ? [-0.16, 0, 0.16] : [0];
    for (const spread of spreads) {
      const group = createProjectile(this.weapon, spread);
      group.position.set(this.player.group.position.x, this.playerY + (this.slideTimer > 0 ? 0.75 : 1.45), -0.65);
      this.entityLayer.add(group);
      this.projectiles.push({
        group, weapon: this.weapon, damage: this.weapon.damage * power,
        vx: spread * 13, speed: this.weapon.projectileSpeed, life: 2.6,
        pierce: this.weapon.id === 'energyBow' ? 3 : 1,
        radius: this.weapon.id === 'fireSword' ? 0.65 : this.weapon.id === 'phoenixOrb' ? 0.85 : 0.38,
      });
    }
  }

  cycleWeapon() {
    if (this.mode !== 'playing' || this.options.unlockedWeapons.length < 2) return;
    const index = this.options.unlockedWeapons.indexOf(this.weapon.id);
    this.weapon = getWeapon(this.options.unlockedWeapons[(index + 1) % this.options.unlockedWeapons.length]);
    this.player.rightArm.remove(this.player.weapon); this.disposeObject(this.player.weapon);
    this.player.weapon = createWeaponModel(this.weapon);
    this.player.weapon.position.set(0, -0.83, -0.04); this.player.weapon.rotation.z = -0.15;
    this.player.rightArm.add(this.player.weapon);
    this.options.onToast(`${this.weapon.name.toUpperCase()} EQUIPPED`, 'info');
    this.options.audio.sfx('select');
  }

  private getAbilityCooldown() {
    return this.character.ability.cooldown * (1 - this.options.upgrades.focus * 0.055) * (this.character.id === 'nyx' ? 0.88 : 1);
  }

  useAbility() {
    if (this.mode !== 'playing' || this.abilityCooldown > 0 || this.boss?.intro) return;
    this.abilityTotal = this.getAbilityCooldown(); this.abilityCooldown = this.abilityTotal;
    this.options.audio.sfx('ability'); this.shake = Math.max(this.shake, 0.35);
    this.createBurst(this.player.group.position.clone().add(new THREE.Vector3(0, 1.2, 0)), this.character.colors.accent, 18);
    switch (this.character.id) {
      case 'kael':
        this.timers.invincible = Math.max(this.timers.invincible, 2.2); this.assassinGap = Math.min(11, this.assassinGap + 3.2); this.clearNearbyTraps(28); break;
      case 'lyra':
        this.freezeTimer = Math.max(this.freezeTimer, 4.2); if (this.boss) this.boss.slow = 4.2; this.clearNearbyTraps(35); break;
      case 'ember':
        this.infernoTimer = 5; this.timers.invincible = Math.max(this.timers.invincible, 1); break;
      case 'thorne':
        this.shield = Math.min(5, this.shield + 3); this.assassinGap = Math.min(11, this.assassinGap + 1.5); break;
      case 'nyx':
        this.slowTimer = 5.5; if (this.boss) this.boss.slow = 5.5; break;
      case 'sora':
        this.health = this.maxHealth; this.reviveTimer = 12; this.timers.invincible = Math.max(this.timers.invincible, 2); break;
      case 'vex':
        if (this.boss) this.damageBoss(48 * this.character.stats.power, this.weapon); this.clearAllTraps(); break;
      case 'mira':
        this.timers.magnet = 11; this.coinMultiplierTimer = 11; break;
      case 'ronan':
        this.timers.jump = 9; if (this.grounded) { this.verticalVelocity = 13.2; this.grounded = false; } this.clearNearbyTraps(15); break;
      case 'zephyr':
        if (this.boss) this.damageBoss(40 * this.character.stats.power, this.weapon); this.clearAllTraps(); this.timers.invincible = 2.5; break;
    }
    this.options.onToast(this.character.ability.name.toUpperCase(), 'reward');
  }

  pause() { if (this.mode === 'playing') { this.mode = 'paused'; this.options.audio.stopMusic(); } }
  resume() { if (this.mode === 'paused') { this.mode = 'playing'; this.lastTime = performance.now(); this.options.audio.startMusic(); } }

  private loop(time: number) {
    if (this.disposed) return;
    const rawDt = this.lastTime ? Math.min((time - this.lastTime) / 1000, 0.05) : 0.016;
    this.lastTime = time;
    if (this.mode === 'playing') this.update(rawDt);
    else if (this.mode === 'over') this.updateAftermath(rawDt);
    this.render(rawDt);
    this.frame = requestAnimationFrame((next) => this.loop(next));
  }

  private update(dt: number) {
    this.elapsed += dt;
    this.hurtCooldown = Math.max(0, this.hurtCooldown - dt);
    this.weaponCooldown = Math.max(0, this.weaponCooldown - dt);
    this.abilityCooldown = Math.max(0, this.abilityCooldown - dt);
    this.attackAnimation = Math.max(0, this.attackAnimation - dt);
    this.slideTimer = Math.max(0, this.slideTimer - dt);
    this.reviveTimer = Math.max(0, this.reviveTimer - dt);
    this.slowTimer = Math.max(0, this.slowTimer - dt);
    this.freezeTimer = Math.max(0, this.freezeTimer - dt);
    this.coinMultiplierTimer = Math.max(0, this.coinMultiplierTimer - dt);
    for (const key of Object.keys(this.timers) as Array<keyof typeof this.timers>) this.timers[key] = Math.max(0, this.timers[key] - dt);
    if (this.infernoTimer > 0) {
      this.infernoTimer -= dt; this.infernoShot -= dt;
      if (this.infernoShot <= 0) { this.infernoShot = 0.42; this.weaponCooldown = 0; const previous = this.weapon; this.weapon = getWeapon('fireSword'); this.attack(); this.weapon = previous; }
    }

    let speed = (13.5 + Math.min(7.5, this.distance / 145)) * this.character.stats.speed;
    if (this.timers.boost > 0) speed *= 1.32;
    if (this.slowTimer > 0) speed *= 0.52;
    if (this.freezeTimer > 0) speed *= 0.14;
    if (this.boss) speed *= this.boss.intro ? 0.14 : 0.76;
    const distanceScale = this.boss ? 0.2 : 0.34;
    this.distance += speed * dt * distanceScale;
    this.scoreBonus += speed * dt * (this.timers.boost > 0 ? 1.8 : 0.35);

    this.updatePlayer(dt);
    this.updateTrack(dt, speed);
    this.updateSpawning(dt);
    this.updateObstacles(dt, speed);
    this.updateCoins(dt, speed);
    this.updatePowerups(dt, speed);
    this.updateProjectiles(dt);
    this.updateAssassin(dt);
    this.updateBoss(dt);
    this.updateEffects(dt);
    this.updateAmbient(dt, speed);

    if (!this.boss && this.distance >= this.nextBossAt) this.startBoss();
    if (this.assassinGap <= 0.5) this.finish('Claimed by the Assassin');
    this.snapshotTimer -= dt;
    if (this.snapshotTimer <= 0) { this.snapshotTimer = 0.09; this.emitSnapshot(); }
  }

  private updateAftermath(dt: number) {
    this.elapsed += dt * 0.25;
    this.updateEffects(dt);
    this.animateRig(this.player, dt, 0.2);
    this.animateRig(this.assassin, dt, 0.5);
  }

  private updatePlayer(dt: number) {
    const targetX = LANES[this.lane];
    this.player.group.position.x = THREE.MathUtils.damp(this.player.group.position.x, targetX, 16, dt);
    if (!this.grounded) {
      this.verticalVelocity -= 21 * dt;
      this.playerY += this.verticalVelocity * dt;
      if (this.playerY <= 0) {
        const impact = this.verticalVelocity;
        this.playerY = 0; this.verticalVelocity = 0; this.grounded = true;
        if (this.character.id === 'ronan' && impact < -8) { this.clearNearbyTraps(13, true); this.shake = 0.35; this.createBurst(this.player.group.position, '#ffcb79', 12); }
      }
    }
    this.player.group.position.y = this.playerY;
    this.player.group.rotation.z = THREE.MathUtils.damp(this.player.group.rotation.z, (targetX - this.player.group.position.x) * -0.11, 9, dt);
    this.animateRig(this.player, dt, 1);
    const auraMat = this.player.aura.material as THREE.MeshBasicMaterial;
    auraMat.opacity = this.timers.invincible > 0 ? 0.45 + Math.sin(this.elapsed * 14) * 0.12 : this.shield > 0 ? 0.24 : 0.07;
    this.player.aura.scale.setScalar(this.timers.invincible > 0 ? 1.35 : 1);
    this.player.aura.rotation.z += dt * 1.4;
  }

  private animateRig(rig: CharacterRig, dt: number, motion: number) {
    const style = rig === this.player ? this.character.id : 'assassin';
    const gait = style === 'thorne' || style === 'ronan' ? 0.78 : style === 'mira' || style === 'vex' ? 1.16 : style === 'nyx' ? 0.88 : 1;
    const run = this.elapsed * (10 + motion * 3) * gait;
    const sliding = rig === this.player && this.slideTimer > 0;
    const jumping = rig === this.player && !this.grounded;
    rig.leftArm.rotation.z = THREE.MathUtils.damp(rig.leftArm.rotation.z, 0, 10, dt);
    rig.head.rotation.z = THREE.MathUtils.damp(rig.head.rotation.z, 0, 8, dt);
    if (sliding) {
      rig.torso.rotation.x = THREE.MathUtils.damp(rig.torso.rotation.x, style === 'mira' ? -1.18 : -1.02, 18, dt);
      rig.torso.position.y = THREE.MathUtils.damp(rig.torso.position.y, 0.8, 18, dt);
      rig.leftLeg.rotation.x = style === 'ronan' ? -0.8 : -1.15; rig.rightLeg.rotation.x = -0.45;
      rig.leftArm.rotation.x = 0.6; rig.rightArm.rotation.x = -0.7;
    } else {
      const heavy = style === 'thorne' || style === 'ronan';
      rig.torso.rotation.x = THREE.MathUtils.damp(rig.torso.rotation.x, jumping ? -0.15 : heavy ? 0.15 : 0.07, 12, dt);
      rig.torso.position.y = THREE.MathUtils.damp(rig.torso.position.y, 1.35 + (jumping ? 0 : Math.abs(Math.sin(run)) * (heavy ? 0.085 : 0.05)), 14, dt);
      if (jumping) {
        rig.leftLeg.rotation.x = style === 'sora' ? -1.05 : -0.65; rig.rightLeg.rotation.x = 0.55;
        rig.leftArm.rotation.x = 0.45; rig.rightArm.rotation.x = -0.5;
      } else {
        const stride = Math.sin(run) * 0.85 * motion * (heavy ? 0.78 : 1);
        rig.leftLeg.rotation.x = stride; rig.rightLeg.rotation.x = -stride;
        rig.leftArm.rotation.x = -stride * (style === 'lyra' ? 0.4 : 0.75); rig.rightArm.rotation.x = stride * 0.75;
      }
    }
    // Each hero keeps a recognizable gait and combat silhouette, even without their colors.
    if (rig === this.player && this.attackAnimation <= 0) {
      if (style === 'lyra') { rig.leftArm.rotation.z = 0.32; rig.rightArm.rotation.z = -0.22; rig.head.rotation.z = Math.sin(run * 0.25) * 0.05; }
      if (style === 'ember') { rig.torso.rotation.y += Math.sin(run * 0.5) * 0.07; rig.leftArm.rotation.x -= 0.25; }
      if (style === 'nyx') { rig.torso.position.y += Math.sin(this.elapsed * 3) * 0.055; rig.leftArm.rotation.z = 0.42 + Math.sin(run * 0.4) * 0.1; }
      if (style === 'sora') { rig.leftArm.rotation.z = 0.55 + Math.sin(run * 0.5) * 0.25; rig.rightArm.rotation.z = -0.35; }
      if (style === 'vex') { rig.head.rotation.x = -0.12; rig.leftArm.rotation.x -= 0.25; }
      if (style === 'mira') { rig.head.rotation.z = Math.sin(run * 0.5) * 0.09; rig.torso.rotation.y += Math.sin(run) * 0.045; }
      if (style === 'zephyr') { rig.leftArm.rotation.z = 0.65; rig.rightArm.rotation.z = -0.5; rig.torso.position.y += Math.sin(this.elapsed * 2) * 0.04; }
    }
    if (rig === this.player && this.attackAnimation > 0) {
      const phase = 1 - this.attackAnimation / 0.32;
      const arc = Math.sin(phase * Math.PI);
      if (this.weapon.id === 'shadowDaggers') {
        rig.rightArm.rotation.x = -1.2 - arc; rig.leftArm.rotation.x = -1.2 - arc;
        rig.rightArm.rotation.z = -0.8 * arc; rig.leftArm.rotation.z = 0.8 * arc;
      } else if (this.weapon.id === 'iceStaff' || this.weapon.id === 'phoenixOrb') {
        rig.rightArm.rotation.x = -1.4 - arc * 1.1; rig.leftArm.rotation.x = -1.1 - arc * 0.7;
        rig.rightArm.rotation.z = -0.25;
      } else if (this.weapon.id === 'energyBow') {
        rig.leftArm.rotation.x = -1.55; rig.rightArm.rotation.x = -1.3 + phase * 0.5; rig.torso.rotation.y = -0.28;
      } else {
        rig.rightArm.rotation.x = -1.5 - arc * 1.3;
        rig.rightArm.rotation.z = this.weapon.id === 'thunderBlade' ? -1.05 * arc : -0.55;
        rig.torso.rotation.y = arc * -0.35;
      }
    } else {
      rig.rightArm.rotation.z = THREE.MathUtils.damp(rig.rightArm.rotation.z, style === 'zephyr' ? -0.5 : style === 'sora' ? -0.35 : style === 'lyra' ? -0.22 : 0, 12, dt);
      rig.torso.rotation.y = THREE.MathUtils.damp(rig.torso.rotation.y, 0, 12, dt);
    }
    if (rig === this.assassin && this.assassinCharge > 0) {
      rig.leftArm.rotation.x = -2.2; rig.rightArm.rotation.x = -2.2;
      rig.torso.rotation.y = Math.sin(this.elapsed * 20) * 0.08;
    }
    rig.cape.rotation.x = -0.15 - motion * 0.25 + Math.sin(run * 0.5) * (style === 'sora' ? 0.15 : 0.08);
    rig.cape.rotation.z = Math.sin(run * 0.33) * (style === 'mira' ? 0.13 : 0.06);
    rig.weapon.rotation.y += dt * (rig === this.assassin ? 0.25 : 0.08);
  }

  private updateTrack(dt: number, speed: number) {
    for (const segment of this.track) {
      segment.position.z += speed * dt;
      if (segment.position.z > 24) segment.position.z -= TRACK_SEGMENTS * TRACK_LENGTH;
    }
  }

  private updateSpawning(dt: number) {
    if (!this.boss) {
      this.spawnTimer -= dt;
      if (this.spawnTimer <= 0) {
        this.spawnPattern();
        const difficulty = Math.min(0.35, this.distance / 1800);
        this.spawnTimer = 1.35 + Math.random() * 0.38 - difficulty;
      }
    } else if (!this.boss.intro) {
      this.spawnTimer -= dt;
      if (this.spawnTimer <= 0) { this.spawnCoinTrail(Math.floor(Math.random() * 3), -62, 5); this.spawnTimer = 3.4; }
    }
    this.powerupTimer -= dt;
    if (this.powerupTimer <= 0 && !this.boss?.intro) { this.spawnPowerup(); this.powerupTimer = 16 + Math.random() * 9; }
  }

  private spawnPattern() {
    const z = -94;
    const safeLane = Math.floor(Math.random() * 3);
    const roll = Math.random();
    const blocked = roll < 0.42 ? [Math.floor(Math.random() * 3)] : [0, 1, 2].filter((lane) => lane !== safeLane);
    const allAction = roll > 0.88;
    const lanes = allAction ? [0, 1, 2] : blocked;
    for (const lane of lanes) {
      let types = this.biome.obstacles;
      if (allAction) types = ['spikes', 'fire', 'laser'] as ObstacleType[];
      const type = types[Math.floor(Math.random() * types.length)];
      // Full-row patterns always retain a jump/slide solution.
      this.spawnObstacle(allAction ? (Math.random() < 0.55 ? 'spikes' : 'laser') : type, lane, z + (allAction ? 0 : Math.random() * -1.2));
    }
    this.spawnCoinTrail(safeLane, z - 3, 5 + Math.floor(Math.random() * 3));
    if (Math.random() < 0.18) this.spawnCoinTrail((safeLane + 1) % 3, z - 14, 4, true);
  }

  private spawnObstacle(type: ObstacleType, lane: number, z: number, fromBoss = false) {
    const group = createObstacle(type, this.biome.accent);
    group.position.set(LANES[lane], 0, z);
    this.entityLayer.add(group);
    const entity: ObstacleEntity = { group, type, lane, z, hit: false, passed: false, fromBoss, phase: Math.random() * Math.PI * 2, hp: type === 'wall' ? 3 : 1 };
    this.obstacles.push(entity);
    return entity;
  }

  private spawnCoinTrail(lane: number, z: number, count: number, arc = false) {
    for (let i = 0; i < count; i++) {
      const group = createCoin();
      const y = arc ? 0.8 + Math.sin((i / Math.max(1, count - 1)) * Math.PI) * 1.45 : 0.85;
      group.position.set(LANES[lane], y, z - i * 2.1);
      this.entityLayer.add(group);
      this.coins.push({ group, x: LANES[lane], y, z: z - i * 2.1, collected: false });
    }
  }

  private spawnPowerup() {
    const types = Object.keys(POWERUPS) as PowerupType[];
    let type = types[Math.floor(Math.random() * types.length)];
    if (this.health === 1 && Math.random() < 0.45) type = 'heal';
    const lane = Math.floor(Math.random() * 3);
    const group = createPowerup(type); group.position.set(LANES[lane], 1.15, -86);
    this.entityLayer.add(group); this.powerups.push({ group, type, x: LANES[lane], z: -86 });
  }

  private updateObstacles(dt: number, speed: number) {
    for (let i = this.obstacles.length - 1; i >= 0; i--) {
      const obstacle = this.obstacles[i];
      obstacle.z += speed * dt * (obstacle.fromBoss ? 1.22 : 1);
      obstacle.group.position.z = obstacle.z;
      const t = this.elapsed + obstacle.phase;
      if (obstacle.type === 'blade') {
        const rotor = obstacle.group.getObjectByName('rotor'); if (rotor) rotor.rotation.z += dt * 7.5;
      } else if (obstacle.type === 'fire') {
        obstacle.group.traverse((child) => { if (child.userData.flame) { child.scale.y = 0.85 + Math.sin(t * 9 + child.id) * 0.18; child.rotation.y += dt * 2; } });
      } else if (obstacle.type === 'electric') {
        obstacle.group.traverse((child) => { if (child.userData.electric) child.scale.x = 0.85 + Math.random() * 0.25; });
      } else if (obstacle.type === 'laser') {
        obstacle.group.traverse((child) => { if (child.userData.laser) child.scale.setScalar(0.8 + Math.sin(t * 15) * 0.2); });
      } else if (obstacle.type === 'magic') {
        obstacle.group.traverse((child) => { if (child.userData.magicRing) { child.rotation.x += dt * 1.2; child.rotation.y += dt * 1.7; } });
        const orb = obstacle.group.getObjectByName('magicOrb'); if (orb) orb.position.y = 1 + Math.sin(t * 4) * 0.2;
      } else if (obstacle.type === 'wall') {
        obstacle.group.position.x = LANES[obstacle.lane] + Math.sin(t * 1.4) * 0.32;
      } else if (obstacle.type === 'bridge' && obstacle.z > -12) {
        obstacle.group.traverse((child) => { if (child.userData.plank) { child.rotation.x += dt * 0.65; child.position.y -= dt * 0.12; } });
      } else if (obstacle.type === 'rock') {
        const rock = obstacle.group.getObjectByName('rock');
        if (rock) { rock.position.y = Math.max(0.9, 6 - Math.max(0, obstacle.z + 24) * 0.32); rock.rotation.x += dt * 2.2; rock.rotation.z += dt * 1.4; }
        const warning = obstacle.group.getObjectByName('warning'); if (warning) warning.scale.setScalar(0.9 + Math.sin(t * 9) * 0.15);
      }
      const collisionDepth = (obstacle.type === 'bridge' ? 1.35 : 0.85) + speed * dt * (obstacle.fromBoss ? 0.61 : 0.5);
      if (!obstacle.hit && Math.abs(obstacle.z - PLAYER_Z) < collisionDepth && Math.abs(obstacle.group.position.x - this.player.group.position.x) < 0.93) {
        if (this.collides(obstacle)) this.hitObstacle(obstacle);
      }
      if (!obstacle.passed && obstacle.z > 1.4) {
        obstacle.passed = true;
        if (!obstacle.hit) {
          this.combo = Math.min(99, this.combo + 1); this.scoreBonus += 12 + this.combo;
          this.assassinGap = Math.min(11, this.assassinGap + (this.character.id === 'kael' ? 0.07 : 0.035));
        }
      }
      if (obstacle.z > 15 || obstacle.hit) this.removeObstacle(obstacle);
    }
  }

  private collides(obstacle: ObstacleEntity) {
    if (this.timers.invincible > 0) { this.createBurst(obstacle.group.position, this.character.colors.accent, 8); obstacle.hit = true; this.scoreBonus += 30; return false; }
    const jumpingHigh = this.playerY > (this.timers.jump > 0 ? 0.65 : 0.95);
    switch (obstacle.type) {
      case 'fire': case 'spikes': case 'bridge': return !jumpingHigh;
      case 'blade': case 'electric': case 'laser': return this.slideTimer <= 0.12;
      case 'magic': return this.playerY < 1.25;
      case 'rock': {
        const rock = obstacle.group.getObjectByName('rock');
        return !rock || rock.position.y < 2.2;
      }
      case 'wall': return true;
    }
  }

  private hitObstacle(obstacle: ObstacleEntity) {
    obstacle.hit = true;
    const damaged = this.damagePlayer(obstacle.type === 'rock' ? 'Crushed by falling rock' : `Struck by ${obstacle.type}`);
    if (!damaged && this.shield > 0) this.options.onToast('AEGIS ABSORBED THE IMPACT', 'info');
    const approach = this.character.id === 'thorne' ? 0.85 : 1.55;
    this.assassinGap -= approach;
    this.combo = 0; this.shake = 0.75;
    this.createBurst(this.player.group.position.clone().add(new THREE.Vector3(0, 0.8, 0)), '#ff5d56', 10);
  }

  private damagePlayer(cause: string): boolean {
    if (this.hurtCooldown > 0 || this.timers.invincible > 0 || this.mode !== 'playing') return false;
    this.hurtCooldown = 1.05;
    if (this.shield > 0) { this.shield--; this.options.audio.sfx('hit'); return false; }
    this.health--; this.bossHurtPlayer = true; this.options.audio.sfx('hit'); this.flashLight = 1;
    if (this.options.settings.haptics && 'vibrate' in navigator) navigator.vibrate?.(45);
    if (this.health <= 0) {
      if (this.reviveTimer > 0) {
        this.reviveTimer = 0; this.health = Math.max(1, Math.ceil(this.maxHealth / 2)); this.timers.invincible = 2.5; this.assassinGap += 3;
        this.options.onToast('PHOENIX SOUL — REBORN', 'reward'); this.options.audio.sfx('heal');
      } else this.finish(cause);
    }
    return true;
  }

  private updateCoins(dt: number, speed: number) {
    const magnet = this.timers.magnet > 0;
    for (let i = this.coins.length - 1; i >= 0; i--) {
      const coin = this.coins[i]; coin.z += speed * dt;
      if (magnet && coin.z > -20 && coin.z < 5) {
        coin.x = THREE.MathUtils.damp(coin.x, this.player.group.position.x, 7, dt);
        coin.y = THREE.MathUtils.damp(coin.y, this.playerY + 1, 7, dt);
        coin.z = THREE.MathUtils.damp(coin.z, 0, 3.5, dt);
      }
      coin.group.position.set(coin.x, coin.y + Math.sin(this.elapsed * 4 + i) * 0.06, coin.z);
      coin.group.rotation.y += dt * 4.5;
      const radius = this.character.id === 'mira' ? 1.15 : 0.78;
      if (!coin.collected && Math.abs(coin.z) < 1 + speed * dt * 0.5 && Math.abs(coin.x - this.player.group.position.x) < radius && Math.abs(coin.y - (this.playerY + 0.85)) < 1.35) {
        coin.collected = true;
        let value = 1;
        const bonusChance = this.options.upgrades.fortune * 0.08 + (this.character.id === 'mira' ? 0.15 : 0);
        if (Math.random() < bonusChance) value++;
        if (this.coinMultiplierTimer > 0) value *= 2;
        this.runCoins += value; this.scoreBonus += 10 * value;
        this.options.audio.sfx('coin');
        this.createBurst(coin.group.position, '#ffd45e', 3);
      }
      if (coin.collected || coin.z > 14) { this.entityLayer.remove(coin.group); this.disposeObject(coin.group); this.coins.splice(i, 1); }
    }
  }

  private updatePowerups(dt: number, speed: number) {
    for (let i = this.powerups.length - 1; i >= 0; i--) {
      const powerup = this.powerups[i]; powerup.z += speed * dt; powerup.group.position.z = powerup.z;
      powerup.group.position.y = 1.15 + Math.sin(this.elapsed * 3 + i) * 0.15;
      powerup.group.rotation.y += dt * 1.5;
      powerup.group.traverse((child) => { if (child.userData.powerRing) child.rotation.z += dt * 1.8; });
      if (Math.abs(powerup.z) < 1 + speed * dt * 0.5 && Math.abs(powerup.x - this.player.group.position.x) < 0.95 && this.playerY < 2) {
        this.collectPowerup(powerup.type); this.createBurst(powerup.group.position, POWERUPS[powerup.type].color, 12);
        powerup.z = 20;
      }
      if (powerup.z > 15) { this.entityLayer.remove(powerup.group); this.disposeObject(powerup.group); this.powerups.splice(i, 1); }
    }
  }

  private collectPowerup(type: PowerupType) {
    if (type === 'shield') this.shield = Math.min(3, this.shield + 1);
    else if (type === 'heal') { this.health = Math.min(this.maxHealth, this.health + 1); if (this.character.id === 'sora') this.shield = Math.min(3, this.shield + 1); }
    else this.timers[type] = Math.max(this.timers[type], POWERUPS[type].duration);
    this.options.audio.sfx(type === 'heal' ? 'heal' : 'powerup');
    this.options.onToast(`${POWERUPS[type].name.toUpperCase()} · ${POWERUPS[type].description.toUpperCase()}`, 'reward');
  }

  private updateProjectiles(dt: number) {
    for (let i = this.projectiles.length - 1; i >= 0; i--) {
      const projectile = this.projectiles[i];
      projectile.life -= dt;
      if (projectile.weapon.id === 'iceStaff' && this.boss) projectile.group.position.x = THREE.MathUtils.damp(projectile.group.position.x, this.boss.rig.group.position.x, 2.8, dt);
      projectile.group.position.x += projectile.vx * dt;
      projectile.group.position.z -= projectile.speed * dt;
      projectile.group.rotation.z += dt * 7;
      let consumed = false;
      const bossHitDepth = 1.6 + projectile.speed * dt * 0.55;
      if (this.boss && !this.boss.intro && Math.abs(projectile.group.position.z + 12) < bossHitDepth && Math.abs(projectile.group.position.x - this.boss.rig.group.position.x) < 1.65) {
        let damage = projectile.damage;
        if (projectile.weapon.id === 'energyBow' && this.boss.telegraph > 0) { damage *= 1.75; this.options.onToast('WEAK-POINT CRITICAL', 'reward'); }
        this.damageBoss(damage, projectile.weapon);
        if (projectile.weapon.id === 'phoenixOrb') this.explodeProjectile(projectile);
        if (projectile.weapon.id === 'fireSword') this.fireSplash(projectile.group.position);
        projectile.pierce--; consumed = true; // Piercing passes through traps, never multi-hits one boss.
      }
      if (!consumed) {
        for (const obstacle of this.obstacles) {
          if (obstacle.hit || obstacle.type === 'bridge') continue;
          if (Math.abs(projectile.group.position.z - obstacle.z) < 0.8 + projectile.radius + projectile.speed * dt * 0.5 && Math.abs(projectile.group.position.x - obstacle.group.position.x) < 0.8 + projectile.radius) {
            obstacle.hp -= projectile.weapon.id === 'phoenixOrb' ? 3 : 1;
            this.createBurst(projectile.group.position, projectile.weapon.color, 5);
            if (obstacle.hp <= 0) { obstacle.hit = true; this.scoreBonus += 45; }
            if (projectile.weapon.id === 'phoenixOrb') this.explodeProjectile(projectile);
            if (projectile.weapon.id === 'fireSword') this.fireSplash(projectile.group.position);
            projectile.pierce--; consumed = projectile.pierce <= 0; break;
          }
        }
      }
      if (consumed || projectile.life <= 0 || projectile.group.position.z < -115) {
        this.entityLayer.remove(projectile.group); this.disposeObject(projectile.group); this.projectiles.splice(i, 1);
      }
    }
  }

  private explodeProjectile(projectile: ProjectileEntity) {
    this.createBurst(projectile.group.position, projectile.weapon.color, 14); this.shake = Math.max(this.shake, 0.25);
    for (const obstacle of this.obstacles) {
      if (!obstacle.hit && obstacle.group.position.distanceTo(projectile.group.position) < 4.5) { obstacle.hit = true; this.scoreBonus += 35; }
    }
  }

  private fireSplash(position: THREE.Vector3) {
    this.createBurst(position, '#ff7138', 7);
    for (const obstacle of this.obstacles) {
      if (!obstacle.hit && obstacle.group.position.distanceTo(position) < 3.4) {
        obstacle.hit = true;
        this.scoreBonus += 25;
      }
    }
  }

  private updateAssassin(dt: number) {
    const drain = 0.024 + Math.min(0.055, this.distance * 0.000045);
    this.assassinGap -= drain * dt * (this.freezeTimer > 0 ? 0.12 : this.slowTimer > 0 ? 0.4 : 1);
    if (this.timers.boost > 0) this.assassinGap = Math.min(11, this.assassinGap + dt * 0.06);
    const targetZ = 0.75 + Math.max(0, this.assassinGap) * 0.59;
    this.assassin.group.position.z = THREE.MathUtils.damp(this.assassin.group.position.z, targetZ, 3.5, dt);
    this.assassin.group.position.x = THREE.MathUtils.damp(this.assassin.group.position.x, this.player.group.position.x * 0.8, 2.8, dt);
    this.assassin.group.position.y = Math.sin(this.elapsed * 4) * 0.08;
    this.animateRig(this.assassin, dt, 1.15);
    this.assassin.aura.rotation.z -= dt * 2;
    this.assassinAttackTimer -= dt;
    if (this.assassinCharge > 0) {
      this.assassinCharge -= dt;
      if (this.assassinCharge <= 0) {
        if (this.lane === this.assassinTargetLane && this.playerY < 1.1) {
          this.damagePlayer('Pierced by the Assassin’s shadow hex'); this.assassinGap -= 0.7; this.shake = 0.65;
        } else { this.options.onToast('SHADOW HEX EVADED', 'info'); this.scoreBonus += 80; }
        this.assassinAttackTimer = Math.max(3.8, 6.5 - this.distance / 450);
      }
    } else if (this.assassinAttackTimer <= 0 && this.assassinGap < 5.2 && !this.boss?.intro) {
      this.assassinCharge = 0.9;
      // The hunter predicts the lane being steered toward, not the lane previously occupied.
      this.assassinTargetLane = this.lane;
      this.spawnWarning(this.assassinTargetLane, '#c15cff', 0.9);
      this.options.onToast('ASSASSIN HEX · CHANGE LANE OR JUMP', 'danger');
    }
  }

  private startBoss() {
    this.clearAllTraps();
    const def = this.biome.boss;
    const rig = createBoss(def); rig.group.position.set(0, 0, -12); this.entityLayer.add(rig.group);
    const maxHp = 90 + this.bossIndex * 24;
    this.boss = {
      rig, hp: maxHp, maxHp, phase: 1, index: this.bossIndex, name: def.name, title: def.title,
      attackTimer: 2.1, telegraph: 0, attack: '', intro: 1.9, slow: 0, targetX: 0, targetLane: 1, safeLane: 1, hitFlash: 0,
    };
    this.bossHurtPlayer = false; this.assassinGap = Math.min(11, this.assassinGap + 2.2);
    this.options.audio.sfx('boss'); this.options.onToast(`${this.nextBossAt} M · ASSASSIN'S GUARDIAN AWAKENS`, 'danger');
    this.shake = 0.5;
  }

  private updateBoss(dt: number) {
    const boss = this.boss; if (!boss) return;
    const def = this.biome.boss;
    if (boss.intro > 0) {
      boss.intro -= dt;
      boss.rig.group.rotation.y = Math.sin(this.elapsed * 0.8) * 0.15;
      if (boss.intro <= 0) this.options.onToast('STRIKE THE CORE · DODGE THE TELEGRAPHS', 'info');
      return;
    }
    boss.slow = Math.max(0, boss.slow - dt); boss.hitFlash = Math.max(0, boss.hitFlash - dt);
    const bossDt = dt * (this.freezeTimer > 0 ? 0.1 : boss.slow > 0 ? 0.55 : 1);
    boss.rig.core.rotation.x += bossDt * 1.5; boss.rig.core.rotation.y += bossDt * 2.2;
    const coreMat = boss.rig.core.material as THREE.MeshStandardMaterial;
    coreMat.emissiveIntensity = boss.hitFlash > 0 ? 2.1 : 1.15 + Math.sin(this.elapsed * 4) * 0.15;
    boss.rig.head.rotation.y = Math.sin(this.elapsed * 0.9) * 0.15;
    boss.rig.group.position.y = Math.sin(this.elapsed * 1.7) * 0.12;
    boss.rig.group.position.x = THREE.MathUtils.damp(boss.rig.group.position.x, boss.targetX, 1.2, bossDt);
    if (Math.random() < dt * 0.25) boss.targetX = LANES[Math.floor(Math.random() * 3)] * 0.65;
    const nextPhase = boss.hp / boss.maxHp > 0.66 ? 1 : boss.hp / boss.maxHp > 0.33 ? 2 : 3;
    if (nextPhase !== boss.phase) {
      boss.phase = nextPhase; boss.attackTimer = 0.7; boss.telegraph = 0;
      this.options.onToast(`PHASE ${nextPhase} · ${nextPhase === 3 ? 'ENRAGED' : 'PATTERN SHIFT'}`, 'danger');
      this.createBurst(boss.rig.group.position.clone().add(new THREE.Vector3(0, 3, 0)), def.accent, 20); this.shake = 0.5;
    }
    if (boss.telegraph > 0) {
      boss.telegraph -= bossDt;
      boss.rig.leftArm.rotation.x = THREE.MathUtils.damp(boss.rig.leftArm.rotation.x, -2.2, 8, bossDt);
      boss.rig.rightArm.rotation.x = THREE.MathUtils.damp(boss.rig.rightArm.rotation.x, -2.2, 8, bossDt);
      if (boss.telegraph <= 0) { this.executeBossAttack(boss.attack); boss.attack = ''; boss.attackTimer = Math.max(1.15, 2.65 - boss.phase * 0.32 - boss.index * 0.035); }
    } else {
      boss.rig.leftArm.rotation.x = THREE.MathUtils.damp(boss.rig.leftArm.rotation.x, 0, 5, bossDt);
      boss.rig.rightArm.rotation.x = THREE.MathUtils.damp(boss.rig.rightArm.rotation.x, 0, 5, bossDt);
      boss.attackTimer -= bossDt;
      if (boss.attackTimer <= 0) {
        const attack = def.attacks[Math.floor(Math.random() * def.attacks.length)];
        boss.attack = attack; boss.telegraph = Math.max(0.62, 1.08 - boss.phase * 0.1);
        boss.targetLane = this.lane;
        boss.safeLane = (this.lane + 1 + Math.floor(Math.random() * 2)) % 3;
        if (attack === 'slam' || attack === 'barrage') this.spawnWarning(boss.targetLane, def.accent, boss.telegraph);
        if (attack === 'drain') {
          for (const lane of [0, 1, 2]) if (lane !== boss.safeLane) this.spawnWarning(lane, def.accent, boss.telegraph);
          this.options.onToast('SOUL DRAIN · MOVE TO THE UNMARKED LANE', 'danger');
        }
        this.options.audio.sfx('boss');
      }
    }
  }

  private executeBossAttack(attack: string) {
    if (!this.boss) return;
    const phase = this.boss.phase;
    const z = -25;
    if (attack === 'slam') {
      const target = this.boss.targetLane;
      const lanes = phase === 1 ? [target] : [0, 1, 2].filter((lane) => lane === target || Math.random() < 0.65);
      for (const lane of lanes) this.spawnObstacle(this.biome.id === 'mountains' ? 'spikes' : 'rock', lane, z - lane * 1.5, true);
    } else if (attack === 'wave') {
      for (const lane of [0, 1, 2]) this.spawnObstacle(this.biome.id === 'city' ? 'fire' : 'spikes', lane, z, true);
      this.options.onToast('SHOCKWAVE · JUMP', 'danger');
    } else if (attack === 'beam') {
      for (const lane of [0, 1, 2]) this.spawnObstacle(this.biome.id === 'castle' ? 'electric' : 'laser', lane, z, true);
      this.options.onToast('SWEEPING BEAM · SLIDE', 'danger');
    } else if (attack === 'barrage') {
      const safe = Math.floor(Math.random() * 3);
      for (let i = 0; i < 3 + phase; i++) {
        const lane = (safe + i + 1) % 3;
        this.spawnObstacle(i % 2 ? 'magic' : 'rock', lane, z - i * 5.5, true);
      }
      this.options.onToast('ARCANE BARRAGE · KEEP MOVING', 'danger');
    } else if (attack === 'storm') {
      const safe = Math.floor(Math.random() * 3);
      for (const lane of [0, 1, 2]) if (lane !== safe) this.spawnObstacle('electric', lane, z, true);
      this.spawnCoinTrail(safe, z - 4, 3);
      this.options.onToast('STORM LANES · FIND THE GAP', 'danger');
    } else if (attack === 'drain') {
      for (const lane of [0, 1, 2]) if (lane !== this.boss.safeLane) this.spawnObstacle('magic', lane, z, true);
      this.assassinGap -= 0.65;
      this.options.onToast('SOUL DRAIN · THE ASSASSIN ADVANCES', 'danger');
    }
    this.shake = 0.35;
  }

  private damageBoss(amount: number, weapon: WeaponDef) {
    const boss = this.boss; if (!boss || boss.intro) return;
    if (this.character.id === 'ember' && Math.random() < 0.2) amount *= 1.45;
    boss.hp -= amount; boss.hitFlash = 0.12; this.weaponHits++;
    if (weapon.id === 'iceStaff') boss.slow = Math.max(boss.slow, this.character.id === 'lyra' ? 2.8 : 2.1);
    this.scoreBonus += Math.round(amount * 3); this.options.audio.sfx('bossHit');
    this.createBurst(boss.rig.group.position.clone().add(new THREE.Vector3((Math.random() - 0.5) * 1.5, 2.7, 0.7)), weapon.color, 6);
    if (this.character.id === 'vex' && this.weaponHits % 5 === 0) { boss.hp -= 18; this.options.onToast('EXILE’S CHAIN LIGHTNING', 'reward'); }
    if (boss.hp <= 0) this.defeatBoss(weapon);
  }

  private defeatBoss(weapon: WeaponDef) {
    const boss = this.boss; if (!boss) return;
    const position = boss.rig.group.position.clone().add(new THREE.Vector3(0, 2.8, 0));
    this.createBurst(position, this.biome.accent, this.quality === 'low' ? 18 : 36);
    this.entityLayer.remove(boss.rig.group); this.disposeObject(boss.rig.group);
    this.bossesDefeated++;
    this.clearAllTraps();
    if (boss.index >= 4) this.ascendedBossDefeated = true;
    if (!this.bossHurtPlayer) this.noHitBoss = true;
    const reward = 45 + boss.index * 15; this.runCoins += reward; this.scoreBonus += 1000 + boss.index * 250;
    this.assassinGap = Math.min(11, this.assassinGap + 2.5);
    if (weapon.id === 'phoenixOrb') this.health = Math.min(this.maxHealth, this.health + 1);
    this.boss = null; this.bossIndex++; this.nextBossAt += 100; this.spawnTimer = 1.8;
    this.options.audio.sfx('explode'); this.options.onToast(`GUARDIAN BANISHED · +${reward} COINS`, 'reward');
    this.buildBiome(this.biomeIndex + 1);
    this.options.onToast(`${this.biome.name.toUpperCase()} · ${this.biome.subtitle.toUpperCase()}`, 'info');
  }

  private spawnWarning(lane: number, color: string, duration: number) {
    const material = new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.7, side: THREE.DoubleSide, depthWrite: false });
    const ring = new THREE.Mesh(new THREE.RingGeometry(0.65, 1.0, 28), material);
    ring.rotation.x = -Math.PI / 2; ring.position.set(LANES[lane], 0.035, -0.2); this.entityLayer.add(ring);
    this.warnings.push({ mesh: ring, life: duration, maxLife: duration });
  }

  private createBurst(position: THREE.Vector3, color: string, count: number) {
    const actual = this.quality === 'low' ? Math.ceil(count * 0.5) : count;
    const material = new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.85, blending: THREE.AdditiveBlending, depthWrite: false });
    for (let i = 0; i < actual; i++) {
      if (this.particles.length > (this.quality === 'low' ? 60 : 150)) break;
      const particle = new THREE.Mesh(new THREE.TetrahedronGeometry(0.045 + Math.random() * 0.075, 0), material.clone());
      particle.position.copy(position); this.entityLayer.add(particle);
      const velocity = new THREE.Vector3((Math.random() - 0.5) * 6, Math.random() * 5, (Math.random() - 0.5) * 5);
      const life = 0.35 + Math.random() * 0.55;
      this.particles.push({ mesh: particle, velocity, life, maxLife: life });
    }
    material.dispose();
  }

  private updateEffects(dt: number) {
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const particle = this.particles[i]; particle.life -= dt; particle.velocity.y -= 7 * dt;
      particle.mesh.position.addScaledVector(particle.velocity, dt); particle.mesh.rotation.x += dt * 5;
      (particle.mesh.material as THREE.MeshBasicMaterial).opacity = Math.max(0, particle.life / particle.maxLife);
      if (particle.life <= 0) { this.entityLayer.remove(particle.mesh); this.disposeObject(particle.mesh); this.particles.splice(i, 1); }
    }
    for (let i = this.warnings.length - 1; i >= 0; i--) {
      const warning = this.warnings[i]; warning.life -= dt;
      const progress = 1 - warning.life / warning.maxLife;
      warning.mesh.scale.setScalar(1 + Math.sin(progress * Math.PI * 5) * 0.15);
      (warning.mesh.material as THREE.MeshBasicMaterial).opacity = Math.max(0, warning.life / warning.maxLife) * 0.75;
      if (warning.life <= 0) { this.entityLayer.remove(warning.mesh); this.disposeObject(warning.mesh); this.warnings.splice(i, 1); }
    }
    this.shake = Math.max(0, this.shake - dt * 2.2); this.flashLight = Math.max(0, this.flashLight - dt * 3);
  }

  private updateAmbient(dt: number, speed: number) {
    if (!this.ambientPoints || !this.ambientPositions) return;
    const positions = this.ambientPositions;
    for (let i = 0; i < positions.length / 3; i++) {
      positions[i * 3 + 2] += speed * dt * 0.22;
      if (this.biome.particle === 'snow') { positions[i * 3 + 1] -= dt * 0.9; positions[i * 3] += Math.sin(this.elapsed + i) * dt * 0.15; }
      else if (this.biome.particle === 'embers' || this.biome.particle === 'fireflies' || this.biome.particle === 'souls') positions[i * 3 + 1] += dt * (this.biome.particle === 'embers' ? 0.8 : 0.12);
      if (positions[i * 3 + 2] > 12) positions[i * 3 + 2] = -110;
      if (positions[i * 3 + 1] < 0 || positions[i * 3 + 1] > 11) positions[i * 3 + 1] = this.biome.particle === 'snow' ? 10 : 0.3;
    }
    (this.ambientPoints.geometry.getAttribute('position') as THREE.BufferAttribute).needsUpdate = true;
  }

  private clearNearbyTraps(range: number, groundOnly = false) {
    for (const obstacle of this.obstacles) {
      if (!obstacle.hit && obstacle.z > -range && obstacle.z < 5 && (!groundOnly || ['spikes', 'fire', 'bridge'].includes(obstacle.type))) {
        this.createBurst(obstacle.group.position.clone().add(new THREE.Vector3(0, 0.7, 0)), this.character.colors.accent, 5);
        obstacle.hit = true; this.scoreBonus += 40;
      }
    }
  }

  private clearAllTraps() { for (const obstacle of this.obstacles) if (!obstacle.hit) { obstacle.hit = true; this.scoreBonus += 20; } }

  private removeObstacle(obstacle: ObstacleEntity, burst = false) {
    if (burst) this.createBurst(obstacle.group.position, this.weapon.color, 5);
    const index = this.obstacles.indexOf(obstacle); if (index >= 0) this.obstacles.splice(index, 1);
    this.entityLayer.remove(obstacle.group); this.disposeObject(obstacle.group);
  }

  private render(dt: number) {
    const aspect = this.camera.aspect;
    const mobile = aspect < 0.85;
    const bossIntro = this.boss && this.boss.intro > 0;
    const targetPosition = bossIntro
      ? new THREE.Vector3(mobile ? 4.5 : 6.5, 4.1, 3.8)
      : new THREE.Vector3(this.player.group.position.x * 0.14, 5.05 + this.playerY * 0.1, mobile ? 12.2 : 10.8);
    if (this.options.settings.cameraShake && this.shake > 0) {
      targetPosition.x += (Math.random() - 0.5) * this.shake * 0.35;
      targetPosition.y += (Math.random() - 0.5) * this.shake * 0.25;
    }
    this.camera.position.lerp(targetPosition, 1 - Math.exp(-dt * (bossIntro ? 3.2 : 7)));
    const look = bossIntro && this.boss
      ? this.boss.rig.group.position.clone().add(new THREE.Vector3(0, 2.7, 0))
      : new THREE.Vector3(this.player.group.position.x * 0.22, 1.25 + this.playerY * 0.08, -9.5);
    this.camera.lookAt(look);
    const targetFov = this.timers.boost > 0 ? 67 : bossIntro ? 54 : 61;
    this.camera.fov = THREE.MathUtils.damp(this.camera.fov, targetFov, 4, dt); this.camera.updateProjectionMatrix();
    this.rim.position.set(this.player.group.position.x, 2.4 + this.playerY, 2.2);
    this.rim.intensity = (this.biome.id === 'city' ? 5 : 7) + this.flashLight * 3;
    this.renderer.render(this.scene, this.camera);
  }

  private emitSnapshot() {
    const activePowerups: Partial<Record<PowerupType, number>> = {};
    for (const [key, value] of Object.entries(this.timers) as Array<[PowerupType, number]>) if (value > 0) activePowerups[key] = value;
    this.options.onSnapshot({
      distance: Math.floor(this.distance), score: this.score, coins: this.runCoins,
      health: this.health, maxHealth: this.maxHealth, shield: this.shield,
      threat: THREE.MathUtils.clamp(1 - this.assassinGap / 9, 0, 1), combo: this.combo,
      biome: this.biome.name, biomeIndex: this.biomeIndex, weapon: this.weapon.id,
      abilityCooldown: this.abilityCooldown, abilityTotal: this.abilityTotal,
      boss: this.boss ? { name: this.boss.name, title: this.boss.title, hp: Math.max(0, this.boss.hp), maxHp: this.boss.maxHp, phase: this.boss.phase, attack: this.boss.attack, intro: this.boss.intro > 0 } : null,
      powerups: activePowerups, speed: this.timers.boost > 0 ? 1.32 : 1,
      assassinAttack: this.assassinCharge > 0,
    });
  }

  private finish(cause: string) {
    if (this.mode === 'over') return;
    this.mode = 'over'; this.emitSnapshot(); this.options.audio.stopMusic(); this.options.audio.sfx('explode');
    this.options.onGameOver({ distance: this.distance, score: this.score, coins: Math.round(this.runCoins), bosses: this.bossesDefeated, noHitBoss: this.noHitBoss, ascended: this.ascendedBossDefeated, cause });
  }

  endRun(cause = 'The hunt was abandoned') { this.finish(cause); }

  private resize() {
    const width = this.options.container.clientWidth || window.innerWidth;
    const height = this.options.container.clientHeight || window.innerHeight;
    this.renderer.setSize(width, height, false); this.camera.aspect = width / Math.max(1, height); this.camera.updateProjectionMatrix();
  }

  private disposeObject(object: THREE.Object3D) {
    object.traverse((child) => {
      const renderable = child as THREE.Mesh;
      if (renderable.geometry) renderable.geometry.dispose();
      if (renderable.material) {
        const materials = Array.isArray(renderable.material) ? renderable.material : [renderable.material];
        for (const material of materials) {
          const withMap = material as THREE.MeshStandardMaterial;
          if (withMap.map) withMap.map.dispose();
          material.dispose();
        }
      }
    });
  }

  dispose() {
    this.disposed = true; cancelAnimationFrame(this.frame); this.resizeObserver.disconnect();
    window.removeEventListener('keydown', this.keyHandler); document.removeEventListener('visibilitychange', this.visibilityHandler);
    this.options.audio.stopMusic(); this.disposeObject(this.scene); this.renderer.dispose();
    this.renderer.domElement.remove();
  }
}
