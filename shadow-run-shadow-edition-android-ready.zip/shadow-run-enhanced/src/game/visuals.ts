import * as THREE from 'three';
import type { BiomeDef, BossDef, CharacterDef, ObstacleType, PowerupType, WeaponDef } from './content';
import { POWERUPS } from './content';

export interface CharacterRig {
  group: THREE.Group;
  torso: THREE.Group;
  head: THREE.Group;
  leftArm: THREE.Group;
  rightArm: THREE.Group;
  leftLeg: THREE.Group;
  rightLeg: THREE.Group;
  cape: THREE.Mesh;
  weapon: THREE.Group;
  aura: THREE.Mesh;
}

const mat = (color: string | number, roughness = 0.65, metalness = 0.05, emissive?: string | number, emissiveIntensity = 0) =>
  new THREE.MeshStandardMaterial({ color, roughness, metalness, emissive: emissive ?? 0x000000, emissiveIntensity });

function mesh(geometry: THREE.BufferGeometry, material: THREE.Material, parent: THREE.Object3D, position: [number, number, number] = [0, 0, 0]) {
  const item = new THREE.Mesh(geometry, material);
  item.position.set(...position);
  item.castShadow = true;
  item.receiveShadow = true;
  parent.add(item);
  return item;
}

function limb(parent: THREE.Object3D, x: number, y: number, material: THREE.Material, length: number, radius: number, boot?: THREE.Material) {
  const pivot = new THREE.Group();
  pivot.position.set(x, y, 0);
  parent.add(pivot);
  const upper = mesh(new THREE.CapsuleGeometry(radius, length * 0.55, 3, 7), material, pivot, [0, -length * 0.32, 0]);
  upper.scale.z = 0.85;
  mesh(new THREE.SphereGeometry(radius * 1.04, 7, 5), material, pivot, [0, -length * 0.64, 0]);
  mesh(new THREE.CapsuleGeometry(radius * 0.82, length * 0.38, 3, 7), material, pivot, [0, -length * 0.82, 0]);
  if (boot) {
    const foot = mesh(new THREE.BoxGeometry(radius * 1.8, radius * 1.35, radius * 2.8), boot, pivot, [0, -length * 1.08, -radius * 0.45]);
    foot.geometry.translate(0, 0, -radius * 0.2);
  }
  return pivot;
}

export function createCharacter(def: CharacterDef, weaponDef: WeaponDef, assassin = false): CharacterRig {
  const group = new THREE.Group();
  const primary = mat(assassin ? '#090a10' : def.colors.primary, 0.76, 0.08);
  const secondary = mat(assassin ? '#1c1528' : def.colors.secondary, 0.4, 0.55);
  const accent = mat(assassin ? '#6c267e' : def.colors.accent, 0.3, 0.4, assassin ? '#8a2cb3' : def.colors.accent, assassin ? 1.25 : 0.45);
  const skin = mat(assassin ? '#292131' : def.colors.skin, 0.88, 0);
  const black = mat('#111319', 0.85, 0.05);
  const torso = new THREE.Group();
  torso.position.y = 1.35;
  group.add(torso);

  const body = mesh(new THREE.CapsuleGeometry(0.37, 0.65, 4, 9), primary, torso, [0, 0.05, 0]);
  body.scale.set(1.05, 1, 0.7);
  mesh(new THREE.BoxGeometry(0.72, 0.16, 0.46), secondary, torso, [0, -0.27, 0]);
  mesh(new THREE.BoxGeometry(0.56, 0.09, 0.49), accent, torso, [0, -0.31, -0.01]);
  for (const side of [-1, 1]) {
    const shoulder = mesh(new THREE.SphereGeometry(0.25, 8, 6, 0, Math.PI * 2, 0, Math.PI * 0.65), secondary, torso, [side * 0.43, 0.29, 0]);
    shoulder.scale.set(1.2, 0.65, 1);
    mesh(new THREE.BoxGeometry(0.06, 0.36, 0.42), accent, torso, [side * 0.32, 0.02, -0.12]).rotation.z = side * -0.2;
  }
  const chestRune = mesh(new THREE.OctahedronGeometry(0.11, 0), accent, torso, [0, 0.12, -0.34]);
  chestRune.scale.y = 1.4;

  const leftArm = limb(torso, -0.45, 0.23, primary, 0.82, 0.115, black);
  const rightArm = limb(torso, 0.45, 0.23, primary, 0.82, 0.115, black);
  const leftLeg = limb(group, -0.22, 1.08, primary, 1.03, 0.145, black);
  const rightLeg = limb(group, 0.22, 1.08, primary, 1.03, 0.145, black);
  for (const leg of [leftLeg, rightLeg]) mesh(new THREE.BoxGeometry(0.23, 0.32, 0.2), secondary, leg, [0, -0.58, -0.1]);

  const head = new THREE.Group();
  head.position.set(0, 0.72, 0);
  torso.add(head);
  mesh(new THREE.CylinderGeometry(0.105, 0.12, 0.18, 7), skin, head, [0, -0.16, 0]);
  const face = mesh(new THREE.SphereGeometry(0.265, 12, 9), skin, head, [0, 0.07, -0.015]);
  face.scale.set(0.85, 1.08, 0.9);
  for (const side of [-1, 1]) {
    const eye = mesh(new THREE.SphereGeometry(0.026, 6, 4), accent, head, [side * 0.092, 0.1, -0.229]);
    eye.scale.set(1.4, 0.55, 0.4);
  }
  mesh(new THREE.BoxGeometry(0.13, 0.025, 0.025), black, head, [0, -0.035, -0.251]);

  if (assassin || def.model === 'hood' || def.model === 'veil' || def.model === 'void') {
    const hood = mesh(new THREE.SphereGeometry(0.36, 10, 8, 0, Math.PI * 2, 0, Math.PI * 0.72), primary, head, [0, 0.11, 0.045]);
    hood.scale.set(1, 1.1, 1);
    const rim = mesh(new THREE.TorusGeometry(0.265, 0.035, 5, 12, Math.PI * 1.25), secondary, head, [0, 0.06, -0.16]);
    rim.rotation.z = -Math.PI * 0.12;
    if (def.model === 'veil' || assassin) {
      const veil = mesh(new THREE.ConeGeometry(0.34, 0.65, 8, 1, true), primary, head, [0, -0.22, 0.07]);
      veil.rotation.x = Math.PI;
    }
  } else if (def.model === 'crown') {
    mesh(new THREE.CylinderGeometry(0.26, 0.29, 0.17, 8), secondary, head, [0, 0.31, 0]);
    for (let i = 0; i < 5; i++) {
      const spike = mesh(new THREE.ConeGeometry(0.045, 0.22 + (i % 2) * 0.08, 5), accent, head, [(i - 2) * 0.105, 0.47 - Math.abs(i - 2) * 0.025, 0]);
      spike.rotation.z = (i - 2) * -0.12;
    }
  } else if (def.model === 'mohawk' || def.model === 'phoenix') {
    for (let i = 0; i < 5; i++) {
      const hair = mesh(new THREE.ConeGeometry(0.09, 0.36 + i * 0.025, 5), def.model === 'phoenix' ? accent : secondary, head, [0, 0.36, (i - 2) * 0.085]);
      hair.rotation.x = (i - 2) * 0.15;
    }
  } else if (def.model === 'horns') {
    for (const side of [-1, 1]) {
      const horn = mesh(new THREE.ConeGeometry(0.09, 0.48, 7), secondary, head, [side * 0.27, 0.35, 0]);
      horn.rotation.z = side * -0.7;
    }
  } else if (def.model === 'topknot') {
    mesh(new THREE.SphereGeometry(0.17, 8, 6), black, head, [0, 0.37, 0.08]);
    const knot = mesh(new THREE.CylinderGeometry(0.045, 0.07, 0.42, 6), black, head, [0, 0.57, 0.08]);
    knot.rotation.z = 0.35;
  } else if (def.model === 'ribbons') {
    mesh(new THREE.SphereGeometry(0.28, 10, 7, 0, Math.PI * 2, 0, Math.PI * 0.6), black, head, [0, 0.17, 0.06]);
    for (const side of [-1, 1]) {
      const ribbon = mesh(new THREE.BoxGeometry(0.07, 0.65, 0.04), accent, head, [side * 0.23, -0.05, 0.22]);
      ribbon.rotation.z = side * 0.25;
    }
  } else if (def.model === 'helm') {
    const helm = mesh(new THREE.SphereGeometry(0.31, 10, 7), secondary, head, [0, 0.1, 0]);
    helm.scale.y = 1.1;
    mesh(new THREE.BoxGeometry(0.38, 0.055, 0.06), accent, head, [0, 0.09, -0.28]);
  }

  const capeMat = new THREE.MeshStandardMaterial({ color: assassin ? '#100b18' : def.colors.secondary, roughness: 0.94, side: THREE.DoubleSide });
  const cape = mesh(new THREE.PlaneGeometry(0.82, 1.2, 1, 3), capeMat, torso, [0, -0.25, 0.29]);
  cape.rotation.x = -0.12;
  cape.castShadow = true;

  const weapon = createWeaponModel(weaponDef, assassin);
  weapon.position.set(0, -0.83, -0.04);
  weapon.rotation.z = assassin ? -0.3 : -0.15;
  rightArm.add(weapon);

  const auraMat = new THREE.MeshBasicMaterial({ color: assassin ? '#a943d0' : def.colors.accent, transparent: true, opacity: assassin ? 0.17 : 0.08, blending: THREE.AdditiveBlending, depthWrite: false });
  const aura = mesh(new THREE.TorusGeometry(0.72, 0.025, 5, 30), auraMat, group, [0, 0.07, 0]);
  aura.rotation.x = Math.PI / 2;
  aura.castShadow = false;
  if (assassin) group.scale.setScalar(1.18);
  return { group, torso, head, leftArm, rightArm, leftLeg, rightLeg, cape, weapon, aura };
}

export function createWeaponModel(def: WeaponDef, assassin = false) {
  const group = new THREE.Group();
  const dark = mat('#17191f', 0.35, 0.75);
  const glow = mat(assassin ? '#a43ac2' : def.color, 0.25, 0.55, assassin ? '#a43ac2' : def.color, 1.1);
  if (assassin) {
    mesh(new THREE.CylinderGeometry(0.025, 0.035, 1.55, 7), dark, group, [0, -0.28, 0]);
    const blade = mesh(new THREE.TorusGeometry(0.32, 0.055, 5, 16, Math.PI * 0.75), glow, group, [0.22, -1.0, 0]);
    blade.rotation.z = 1.2;
  } else if (def.id === 'iceStaff') {
    mesh(new THREE.CylinderGeometry(0.025, 0.04, 1.35, 7), dark, group, [0, -0.35, 0]);
    mesh(new THREE.OctahedronGeometry(0.18, 0), glow, group, [0, -1.08, 0]);
    const ring = mesh(new THREE.TorusGeometry(0.25, 0.025, 5, 16), glow, group, [0, -1.08, 0]); ring.rotation.x = Math.PI / 2;
  } else if (def.id === 'energyBow') {
    const bow = mesh(new THREE.TorusGeometry(0.42, 0.035, 5, 20, Math.PI * 1.3), glow, group, [0, -0.55, 0]);
    bow.rotation.z = -Math.PI * 0.65;
    mesh(new THREE.CylinderGeometry(0.008, 0.008, 0.78, 4), dark, group, [0, -0.55, 0]);
  } else if (def.id === 'phoenixOrb') {
    mesh(new THREE.SphereGeometry(0.18, 10, 8), glow, group, [0, -0.85, 0]);
    const ring = mesh(new THREE.TorusGeometry(0.27, 0.025, 5, 18), glow, group, [0, -0.85, 0]); ring.rotation.x = 0.5;
  } else if (def.id === 'shadowDaggers') {
    for (const x of [-0.11, 0.11]) {
      const dagger = mesh(new THREE.ConeGeometry(0.075, 0.7, 4), glow, group, [x, -0.63, 0]);
      dagger.rotation.z = x * 1.2;
    }
  } else {
    mesh(new THREE.CylinderGeometry(0.035, 0.045, 0.38, 7), dark, group, [0, -0.25, 0]);
    mesh(new THREE.BoxGeometry(0.36, 0.055, 0.09), dark, group, [0, -0.45, 0]);
    const blade = mesh(def.id === 'thunderBlade' ? new THREE.BoxGeometry(0.09, 0.95, 0.035) : new THREE.ConeGeometry(0.11, 1.05, 4), glow, group, [0, -0.95, 0]);
    if (def.id === 'fireSword') blade.rotation.y = Math.PI / 4;
  }
  return group;
}

export function createObstacle(type: ObstacleType, accent: string): THREE.Group {
  const group = new THREE.Group();
  const stone = mat('#34383b', 0.92, 0.04);
  const metal = mat('#59636c', 0.3, 0.82);
  const dark = mat('#171b20', 0.7, 0.35);
  const glow = mat(accent, 0.25, 0.25, accent, 1.35);
  if (type === 'fire') {
    mesh(new THREE.CylinderGeometry(0.65, 0.8, 0.25, 8), stone, group, [0, 0.12, 0]);
    for (let i = 0; i < 5; i++) {
      const flame = mesh(new THREE.ConeGeometry(0.22 + (i % 2) * 0.1, 1.1 + (i % 3) * 0.25, 7), i % 2 ? glow : mat('#ff5b24', 0.3, 0, '#ff3c16', 1.4), group, [(i - 2) * 0.24, 0.75, (i % 2) * 0.18]);
      flame.userData.flame = true;
    }
  } else if (type === 'blade') {
    mesh(new THREE.CylinderGeometry(0.22, 0.3, 1.5, 8), dark, group, [0, 0.75, 0]);
    const rotor = new THREE.Group(); rotor.position.y = 1.05; rotor.name = 'rotor'; group.add(rotor);
    mesh(new THREE.SphereGeometry(0.24, 8, 6), metal, rotor);
    for (let i = 0; i < 4; i++) {
      const blade = mesh(new THREE.ConeGeometry(0.24, 1.25, 4), metal, rotor, [0, 0, 0]);
      blade.rotation.z = i * Math.PI / 2; blade.position.set(Math.cos(i * Math.PI / 2) * 0.62, Math.sin(i * Math.PI / 2) * 0.62, 0);
    }
  } else if (type === 'spikes') {
    mesh(new THREE.BoxGeometry(1.8, 0.18, 1.25), stone, group, [0, 0.09, 0]);
    for (let x = -1; x <= 1; x++) for (let z = -1; z <= 1; z++) mesh(new THREE.ConeGeometry(0.16, 0.9 + (x + z + 2) % 2 * 0.25, 6), metal, group, [x * 0.48, 0.55, z * 0.34]);
  } else if (type === 'bridge') {
    const hole = mesh(new THREE.BoxGeometry(2.1, 0.12, 2.6), mat('#080b10', 1), group, [0, -0.13, 0]);
    hole.receiveShadow = false;
    for (let i = 0; i < 4; i++) {
      const plank = mesh(new THREE.BoxGeometry(1.95, 0.12, 0.5), mat(i % 2 ? '#54483b' : '#443a31', 0.95), group, [0, -0.02 - i * 0.04, (i - 1.5) * 0.6]);
      plank.rotation.z = (i - 1.5) * 0.07; plank.userData.plank = true;
    }
  } else if (type === 'rock') {
    const rock = mesh(new THREE.DodecahedronGeometry(0.85, 1), mat('#4a4643', 0.96), group, [0, 0, 0]);
    rock.scale.set(1, 1.25, 0.9); rock.name = 'rock';
    const ring = mesh(new THREE.RingGeometry(0.6, 0.85, 24), new THREE.MeshBasicMaterial({ color: '#ff6b45', transparent: true, opacity: 0.6, side: THREE.DoubleSide }), group, [0, 0.035, 0]);
    ring.rotation.x = -Math.PI / 2; ring.name = 'warning';
  } else if (type === 'electric') {
    for (const x of [-0.85, 0.85]) {
      mesh(new THREE.BoxGeometry(0.18, 2.6, 0.24), dark, group, [x, 1.3, 0]);
      mesh(new THREE.SphereGeometry(0.13, 7, 5), glow, group, [x, 2.5, 0]);
    }
    for (let i = 0; i < 3; i++) {
      const beam = mesh(new THREE.CylinderGeometry(0.025, 0.025, 1.7, 5), glow, group, [0, 1.15 + i * 0.35, 0]);
      beam.rotation.z = Math.PI / 2 + (i - 1) * 0.05; beam.userData.electric = true;
    }
  } else if (type === 'wall') {
    const wall = mesh(new THREE.BoxGeometry(1.95, 3.3, 0.7), stone, group, [0, 1.65, 0]);
    for (let y = 0; y < 4; y++) for (const x of [-0.55, 0.55]) mesh(new THREE.BoxGeometry(0.72, 0.05, 0.73), dark, group, [x + (y % 2) * 0.15, 0.5 + y * 0.7, -0.02]);
    mesh(new THREE.OctahedronGeometry(0.25, 0), glow, group, [0, 1.75, -0.43]);
    wall.receiveShadow = true;
  } else if (type === 'laser') {
    for (const x of [-0.85, 0.85]) mesh(new THREE.BoxGeometry(0.14, 1.8, 0.2), dark, group, [x, 0.9, 0]);
    const beam = mesh(new THREE.CylinderGeometry(0.045, 0.045, 1.72, 7), glow, group, [0, 1.15, 0]);
    beam.rotation.z = Math.PI / 2; beam.userData.laser = true;
    const halo = mesh(new THREE.CylinderGeometry(0.09, 0.09, 1.72, 7), new THREE.MeshBasicMaterial({ color: accent, transparent: true, opacity: 0.18, blending: THREE.AdditiveBlending, depthWrite: false }), group, [0, 1.15, 0]);
    halo.rotation.z = Math.PI / 2;
  } else {
    const orb = mesh(new THREE.IcosahedronGeometry(0.45, 1), glow, group, [0, 1, 0]); orb.name = 'magicOrb';
    for (let i = 0; i < 3; i++) {
      const ring = mesh(new THREE.TorusGeometry(0.65 + i * 0.12, 0.025, 5, 22), glow, group, [0, 1, 0]);
      ring.rotation.set(i * 0.7, i * 0.8, i); ring.userData.magicRing = true;
    }
  }
  return group;
}

export function createCoin() {
  const group = new THREE.Group();
  const gold = mat('#f6ba38', 0.25, 0.75, '#ffb629', 0.25);
  const coin = mesh(new THREE.CylinderGeometry(0.25, 0.25, 0.075, 12), gold, group);
  coin.rotation.x = Math.PI / 2;
  for (const side of [-1, 1]) mesh(new THREE.TorusGeometry(0.13, 0.025, 4, 8), mat('#fff0a0', 0.3, 0.5, '#ffc64d', 0.35), group, [0, 0, side * 0.055]);
  return group;
}

export function createPowerup(type: PowerupType) {
  const group = new THREE.Group();
  const color = POWERUPS[type].color;
  const glow = mat(color, 0.25, 0.35, color, 1.1);
  const core = mesh(type === 'heal' ? new THREE.OctahedronGeometry(0.34, 0) : new THREE.IcosahedronGeometry(0.32, 1), glow, group, [0, 0, 0]);
  core.name = 'powerCore';
  for (let i = 0; i < 2; i++) {
    const ring = mesh(new THREE.TorusGeometry(0.5, 0.025, 5, 20), glow, group);
    ring.rotation.set(i * Math.PI / 2, 0, i * 0.5); ring.userData.powerRing = true;
  }
  return group;
}

export function createBoss(def: BossDef): { group: THREE.Group; core: THREE.Mesh; leftArm: THREE.Group; rightArm: THREE.Group; head: THREE.Group } {
  const group = new THREE.Group();
  const armor = mat(def.color, 0.5, def.shape === 'treant' ? 0.05 : 0.55);
  const dark = mat('#16141c', 0.72, 0.25);
  const glow = mat(def.accent, 0.25, 0.3, def.accent, 1.25);
  const torso = new THREE.Group(); torso.position.y = 2.7; group.add(torso);
  const trunk = mesh(new THREE.CapsuleGeometry(def.shape === 'colossus' ? 1.15 : 0.85, 1.65, 5, 10), armor, torso);
  trunk.scale.z = 0.7;
  const core = mesh(new THREE.OctahedronGeometry(0.38, 1), glow, torso, [0, 0.1, 0.72]);
  core.scale.y = 1.35;
  for (const side of [-1, 1]) mesh(new THREE.SphereGeometry(0.65, 9, 7), armor, torso, [side * 1.05, 0.7, 0]);
  const leftArm = limb(torso, -1.12, 0.58, armor, 1.75, 0.3, dark);
  const rightArm = limb(torso, 1.12, 0.58, armor, 1.75, 0.3, dark);
  const head = new THREE.Group(); head.position.y = 1.55; torso.add(head);
  if (def.shape === 'treant') {
    for (let i = 0; i < 7; i++) {
      const branch = mesh(new THREE.CylinderGeometry(0.07, 0.18, 1.3 + (i % 3) * 0.35, 6), armor, head, [(i - 3) * 0.22, 0.4, 0]);
      branch.rotation.z = (i - 3) * -0.16;
    }
    const skull = mesh(new THREE.DodecahedronGeometry(0.65, 0), dark, head);
    skull.scale.y = 1.15;
  } else if (def.shape === 'idol') {
    mesh(new THREE.CylinderGeometry(0.65, 0.8, 1.1, 6), armor, head);
    for (let i = 0; i < 8; i++) {
      const ray = mesh(new THREE.ConeGeometry(0.12, 0.8, 4), glow, head, [Math.cos(i * Math.PI / 4) * 0.85, Math.sin(i * Math.PI / 4) * 0.85, 0]);
      ray.rotation.z = i * Math.PI / 4 - Math.PI / 2;
    }
    const halo = mesh(new THREE.TorusGeometry(1.15, 0.08, 6, 28), glow, head); halo.name = 'bossHalo';
  } else if (def.shape === 'knight') {
    mesh(new THREE.SphereGeometry(0.62, 10, 8), armor, head);
    mesh(new THREE.BoxGeometry(0.85, 0.12, 0.12), glow, head, [0, 0.05, 0.57]);
    for (const side of [-1, 1]) { const horn = mesh(new THREE.ConeGeometry(0.16, 0.9, 6), dark, head, [side * 0.55, 0.45, 0]); horn.rotation.z = side * -0.65; }
    const sword = createWeaponModel({ id: 'fireSword', color: def.accent } as WeaponDef, true); sword.scale.setScalar(1.6); sword.position.y = -1.4; rightArm.add(sword);
  } else if (def.shape === 'colossus') {
    const skull = mesh(new THREE.DodecahedronGeometry(0.78, 1), dark, head); skull.scale.y = 0.9;
    for (let i = 0; i < 5; i++) mesh(new THREE.ConeGeometry(0.16, 0.75, 5), armor, head, [(i - 2) * 0.3, 0.62, 0]);
    for (let i = 0; i < 6; i++) mesh(new THREE.BoxGeometry(0.08, 0.7, 0.08), glow, torso, [(i - 2.5) * 0.3, 0.1 + (i % 2) * 0.4, 0.72]).rotation.z = (i - 2) * 0.15;
  } else {
    const skull = mesh(new THREE.OctahedronGeometry(0.72, 1), armor, head); skull.scale.y = 1.2;
    for (let i = 0; i < 6; i++) { const shard = mesh(new THREE.ConeGeometry(0.13, 0.9, 5), glow, head, [(i - 2.5) * 0.25, 0.65, 0]); shard.rotation.z = (i - 2.5) * -0.15; }
    const cape = mesh(new THREE.ConeGeometry(1.35, 3.4, 9, 1, true), new THREE.MeshStandardMaterial({ color: def.color, roughness: 0.8, transparent: true, opacity: 0.7, side: THREE.DoubleSide }), group, [0, 1.7, 0]); cape.rotation.x = Math.PI;
  }
  for (const side of [-1, 1]) {
    const eye = mesh(new THREE.SphereGeometry(0.11, 7, 5), glow, head, [side * 0.25, 0.12, 0.58]); eye.scale.y = 0.6;
  }
  for (const side of [-1, 1]) limb(group, side * 0.55, 1.55, dark, 1.65, 0.32, dark);
  group.scale.setScalar(0.92);
  return { group, core, leftArm, rightArm, head };
}

function groundTexture(biome: BiomeDef) {
  const canvas = document.createElement('canvas'); canvas.width = canvas.height = 128;
  const ctx = canvas.getContext('2d')!;
  ctx.fillStyle = biome.ground; ctx.fillRect(0, 0, 128, 128);
  for (let i = 0; i < 420; i++) {
    const shade = Math.random() > 0.5 ? 255 : 0;
    ctx.fillStyle = `rgba(${shade},${shade},${shade},${Math.random() * 0.055})`;
    const size = 1 + Math.random() * 4; ctx.fillRect(Math.random() * 128, Math.random() * 128, size, size);
  }
  ctx.strokeStyle = biome.id === 'mountains' ? 'rgba(255,255,255,.18)' : 'rgba(0,0,0,.2)'; ctx.lineWidth = 1;
  for (let i = 0; i < 12; i++) {
    let x = Math.random() * 128, y = Math.random() * 128; ctx.beginPath(); ctx.moveTo(x, y);
    for (let j = 0; j < 4; j++) { x += Math.random() * 14 - 7; y += Math.random() * 15; ctx.lineTo(x, y); }
    ctx.stroke();
  }
  const texture = new THREE.CanvasTexture(canvas); texture.wrapS = texture.wrapT = THREE.RepeatWrapping; texture.repeat.set(2, 3); texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

export function createTrackSegment(biome: BiomeDef, index: number, quality: 'low' | 'medium' | 'high') {
  const group = new THREE.Group();
  const ground = new THREE.MeshStandardMaterial({ color: '#ffffff', map: groundTexture(biome), roughness: biome.id === 'mountains' ? 0.62 : 0.94, metalness: biome.id === 'temple' ? 0.12 : 0.02 });
  const slab = mesh(new THREE.BoxGeometry(7.6, 0.35, 12), ground, group, [0, -0.23, 0]); slab.receiveShadow = true; slab.castShadow = false;
  const edge = mat(biome.edge, 0.72, biome.id === 'temple' ? 0.3 : 0.08);
  for (const x of [-3.95, 3.95]) mesh(new THREE.BoxGeometry(0.28, 0.45, 12), edge, group, [x, -0.05, 0]);
  const count = quality === 'low' ? 1 : quality === 'medium' ? 2 : 3;
  for (const side of [-1, 1]) for (let i = 0; i < count; i++) {
    const x = side * (5.2 + ((index + i) % 3) * 1.25);
    const z = -4 + i * 4 + (index % 2) * 1.1;
    if (biome.id === 'forest') {
      const trunk = mesh(new THREE.CylinderGeometry(0.22, 0.42, 4.5, 7), mat('#26352c', 1), group, [x, 2.1, z]); trunk.rotation.z = side * 0.08;
      for (let j = 0; j < 3; j++) {
        const crown = mesh(new THREE.ConeGeometry(1.4 - j * 0.15, 2.8, 7), mat(j % 2 ? '#16382e' : '#1c4435', 0.95), group, [x + side * j * 0.2, 4.1 + j * 0.75, z]); crown.rotation.z = side * 0.1;
      }
      if (quality === 'high') for (let j = 0; j < 2; j++) { const root = mesh(new THREE.CylinderGeometry(0.07, 0.16, 1.8, 5), edge, group, [x + side * 0.5, 0.12, z + j]); root.rotation.z = side * 1.1; }
    } else if (biome.id === 'temple') {
      mesh(new THREE.CylinderGeometry(0.48, 0.62, 5.8, 8), edge, group, [x, 2.8, z]);
      mesh(new THREE.BoxGeometry(1.35, 0.38, 1.35), edge, group, [x, 5.65, z]);
      for (let y = 0; y < 4; y++) mesh(new THREE.TorusGeometry(0.5, 0.045, 4, 8), mat('#9b7c46', 0.55, 0.35), group, [x, 1 + y, z]).rotation.x = Math.PI / 2;
    } else if (biome.id === 'castle') {
      mesh(new THREE.BoxGeometry(2.4, 6 + (index % 2) * 2, 2.2), mat('#232334', 0.88), group, [x, 3, z]);
      for (let j = 0; j < 3; j++) mesh(new THREE.ConeGeometry(0.35, 1.2, 4), edge, group, [x + (j - 1) * 0.75, 6.4 + (index % 2), z]);
      const windowMat = mat('#5f3785', 0.4, 0, '#8b54b8', 0.65);
      mesh(new THREE.BoxGeometry(0.4, 1.1, 0.05), windowMat, group, [x - side * 1.21, 3.8, z]);
    } else if (biome.id === 'city') {
      const height = 5 + ((index + i) % 4) * 1.5;
      mesh(new THREE.BoxGeometry(2.8, height, 2.8), mat('#332c2d', 0.9), group, [x, height / 2, z]);
      for (let y = 1; y < height - 1; y += 1.5) mesh(new THREE.BoxGeometry(0.5, 0.55, 0.04), mat('#8f3c22', 0.6, 0, '#ff592c', 0.55), group, [x - side * 1.42, y, z]);
      if (quality !== 'low') { const antenna = mesh(new THREE.CylinderGeometry(0.04, 0.07, 2.4, 5), edge, group, [x, height + 1.2, z]); antenna.rotation.z = 0.08; }
    } else {
      const mountain = mesh(new THREE.ConeGeometry(2.5 + (index % 2), 7 + i, 6), mat(i % 2 ? '#7f9eac' : '#9db5bf', 0.82), group, [x + side * 2, 3, z]);
      mountain.rotation.y = index * 0.7;
      const cap = mesh(new THREE.ConeGeometry(1.25, 2.5, 6), mat('#d9e7e9', 0.65), group, [x + side * 2, 6.1 + i * 0.5, z]); cap.rotation.y = index * 0.7;
    }
  }
  return group;
}

export function createProjectile(def: WeaponDef, spread = 0) {
  const group = new THREE.Group();
  const glow = mat(def.color, 0.2, 0.3, def.color, 1.5);
  let geometry: THREE.BufferGeometry;
  if (def.id === 'fireSword') geometry = new THREE.TorusGeometry(0.38, 0.09, 5, 12, Math.PI);
  else if (def.id === 'energyBow') geometry = new THREE.ConeGeometry(0.1, 1.2, 5);
  else if (def.id === 'shadowDaggers') geometry = new THREE.ConeGeometry(0.09, 0.65, 4);
  else if (def.id === 'phoenixOrb') geometry = new THREE.SphereGeometry(0.35, 9, 7);
  else geometry = new THREE.OctahedronGeometry(def.id === 'thunderBlade' ? 0.2 : 0.24, 0);
  const core = mesh(geometry, glow, group); core.rotation.x = Math.PI / 2;
  const halo = mesh(new THREE.SphereGeometry(def.id === 'phoenixOrb' ? 0.48 : 0.25, 7, 5), new THREE.MeshBasicMaterial({ color: def.color, transparent: true, opacity: 0.14, blending: THREE.AdditiveBlending, depthWrite: false }), group);
  halo.castShadow = false; group.rotation.y = spread;
  return group;
}
