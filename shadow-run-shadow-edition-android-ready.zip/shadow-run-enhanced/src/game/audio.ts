import type { BiomeId, WeaponId } from './content';

type SfxName = 'coin' | 'jump' | 'slide' | 'hit' | 'attack' | 'ability' | 'powerup' | 'boss' | 'bossHit' | 'select' | 'explode' | 'heal';

/** Lightweight procedural audio: no downloads and no audio decode stalls on mobile. */
export class GameAudio {
  private context?: AudioContext;
  private master?: GainNode;
  private musicGain?: GainNode;
  private sfxGain?: GainNode;
  private musicTimer?: number;
  private step = 0;
  private biome: BiomeId = 'forest';
  private musicVolume = 0.35;
  private sfxVolume = 0.65;
  private running = false;

  private ensure() {
    if (!this.context) {
      const AudioCtor = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtor) return false;
      this.context = new AudioCtor();
      this.master = this.context.createGain();
      this.musicGain = this.context.createGain();
      this.sfxGain = this.context.createGain();
      this.musicGain.connect(this.master);
      this.sfxGain.connect(this.master);
      this.master.connect(this.context.destination);
      this.master.gain.value = 0.7;
      this.applyVolumes();
    }
    if (this.context.state === 'suspended') void this.context.resume();
    return true;
  }

  unlock() { this.ensure(); }

  setVolumes(music: number, sfx: number) {
    this.musicVolume = music;
    this.sfxVolume = sfx;
    this.applyVolumes();
  }

  private applyVolumes() {
    if (!this.context) return;
    this.musicGain!.gain.setTargetAtTime(this.musicVolume * 0.32, this.context.currentTime, 0.05);
    this.sfxGain!.gain.setTargetAtTime(this.sfxVolume * 0.5, this.context.currentTime, 0.03);
  }

  setBiome(biome: BiomeId) { this.biome = biome; this.step = 0; }

  startMusic() {
    if (this.running) return;
    this.running = true;
    if (!this.ensure()) return;
    const tick = () => {
      if (!this.running || !this.context) return;
      const roots: Record<BiomeId, number[]> = {
        forest: [110, 130.81, 146.83, 98],
        temple: [123.47, 146.83, 164.81, 110],
        castle: [92.5, 110, 103.83, 82.41],
        city: [98, 116.54, 130.81, 87.31],
        mountains: [130.81, 155.56, 174.61, 116.54],
      };
      const root = roots[this.biome][Math.floor(this.step / 4) % 4];
      const scale = [1, 1.1892, 1.4983, 2, 1.7818, 1.3348, 1.1892, 1.4983];
      if (this.step % 2 === 0) this.tone(root / 2, 0.35, 'sine', 0.18, this.musicGain!);
      this.tone(root * scale[this.step % 8] * 2, 0.18, this.biome === 'city' ? 'sawtooth' : 'triangle', 0.065, this.musicGain!);
      if (this.step % 4 === 0) this.noise(0.06, 0.04, this.musicGain!);
      this.step++;
      this.musicTimer = window.setTimeout(tick, this.biome === 'city' ? 175 : 210);
    };
    tick();
  }

  stopMusic() {
    this.running = false;
    if (this.musicTimer) window.clearTimeout(this.musicTimer);
  }

  sfx(name: SfxName, weapon?: WeaponId) {
    if (!this.ensure() || !this.context || !this.sfxGain) return;
    const now = this.context.currentTime;
    switch (name) {
      case 'coin': this.tone(880, 0.07, 'sine', 0.25); this.tone(1320, 0.1, 'sine', 0.16, undefined, 0.045); break;
      case 'jump': this.sweep(180, 460, 0.18, 'triangle', 0.2); break;
      case 'slide': this.noise(0.18, 0.15); break;
      case 'hit': this.noise(0.24, 0.42); this.sweep(130, 48, 0.3, 'sawtooth', 0.24); break;
      case 'attack': {
        const freq = weapon === 'iceStaff' ? 640 : weapon === 'thunderBlade' ? 1000 : weapon === 'phoenixOrb' ? 140 : 320;
        this.sweep(freq, freq * 0.45, 0.16, weapon === 'thunderBlade' ? 'square' : 'sawtooth', 0.15); break;
      }
      case 'ability': this.sweep(90, 780, 0.55, 'sine', 0.32); this.tone(1170, 0.5, 'triangle', 0.12, undefined, 0.12); break;
      case 'powerup': [0, 0.08, 0.16].forEach((d, i) => this.tone(440 * (1 + i * 0.25), 0.16, 'sine', 0.18, undefined, d)); break;
      case 'boss': this.sweep(70, 38, 1.2, 'sawtooth', 0.32); this.noise(0.7, 0.18); break;
      case 'bossHit': this.noise(0.08, 0.16); this.tone(180, 0.09, 'square', 0.08); break;
      case 'select': this.tone(520, 0.06, 'sine', 0.13); break;
      case 'explode': this.noise(0.5, 0.35); this.sweep(180, 35, 0.55, 'sawtooth', 0.3); break;
      case 'heal': this.sweep(330, 880, 0.4, 'sine', 0.2); break;
    }
    void now;
  }

  private tone(frequency: number, duration: number, type: OscillatorType, volume: number, output?: GainNode, delay = 0) {
    if (!this.context) return;
    const t = this.context.currentTime + delay;
    const osc = this.context.createOscillator();
    const gain = this.context.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(frequency, t);
    gain.gain.setValueAtTime(0.0001, t);
    gain.gain.exponentialRampToValueAtTime(Math.max(0.0002, volume), t + 0.012);
    gain.gain.exponentialRampToValueAtTime(0.0001, t + duration);
    osc.connect(gain); gain.connect(output ?? this.sfxGain!);
    osc.start(t); osc.stop(t + duration + 0.03);
  }

  private sweep(from: number, to: number, duration: number, type: OscillatorType, volume: number) {
    if (!this.context) return;
    const t = this.context.currentTime;
    const osc = this.context.createOscillator();
    const gain = this.context.createGain();
    osc.type = type; osc.frequency.setValueAtTime(from, t); osc.frequency.exponentialRampToValueAtTime(Math.max(20, to), t + duration);
    gain.gain.setValueAtTime(volume, t); gain.gain.exponentialRampToValueAtTime(0.0001, t + duration);
    osc.connect(gain); gain.connect(this.sfxGain!); osc.start(t); osc.stop(t + duration + 0.02);
  }

  private noise(duration: number, volume: number, output?: GainNode) {
    if (!this.context) return;
    const length = Math.ceil(this.context.sampleRate * duration);
    const buffer = this.context.createBuffer(1, length, this.context.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < length; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / length);
    const source = this.context.createBufferSource();
    const filter = this.context.createBiquadFilter();
    const gain = this.context.createGain();
    filter.type = 'lowpass'; filter.frequency.value = 1600;
    gain.gain.value = volume;
    source.buffer = buffer; source.connect(filter); filter.connect(gain); gain.connect(output ?? this.sfxGain!); source.start();
  }

  dispose() { this.stopMusic(); if (this.context) void this.context.close(); this.context = undefined; }
}
