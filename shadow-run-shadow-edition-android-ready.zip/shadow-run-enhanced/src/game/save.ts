import { ACHIEVEMENTS, CHARACTERS, WEAPONS, type CharacterId, type GraphicsQuality, type WeaponId } from './content';

export interface UpgradeSet { vitality: number; focus: number; fortune: number }
export interface Settings {
  graphics: GraphicsQuality;
  music: number;
  sfx: number;
  haptics: boolean;
  cameraShake: boolean;
  leftHanded: boolean;
}

export interface SaveData {
  version: 1;
  coins: number;
  selectedCharacter: CharacterId;
  selectedWeapon: WeaponId;
  unlockedCharacters: CharacterId[];
  unlockedWeapons: WeaponId[];
  upgrades: Partial<Record<CharacterId, UpgradeSet>>;
  bestScore: number;
  bestDistance: number;
  totalRuns: number;
  totalCoins: number;
  bossesDefeated: number;
  achievements: string[];
  settings: Settings;
}

const KEY = 'shadow-run-assassin-save-v1';

export const defaultSave = (): SaveData => ({
  version: 1,
  coins: 0,
  selectedCharacter: 'kael',
  selectedWeapon: 'fireSword',
  unlockedCharacters: ['kael'],
  unlockedWeapons: ['fireSword'],
  upgrades: {},
  bestScore: 0,
  bestDistance: 0,
  totalRuns: 0,
  totalCoins: 0,
  bossesDefeated: 0,
  achievements: [],
  settings: { graphics: 'high', music: 0.35, sfx: 0.65, haptics: true, cameraShake: true, leftHanded: false },
});

export function loadSave(): SaveData {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return defaultSave();
    const parsed = JSON.parse(raw) as Partial<SaveData>;
    const base = defaultSave();
    const validCharacters = (parsed.unlockedCharacters ?? base.unlockedCharacters).filter((id) => CHARACTERS.some((c) => c.id === id));
    const validWeapons = (parsed.unlockedWeapons ?? base.unlockedWeapons).filter((id) => WEAPONS.some((w) => w.id === id));
    if (!validCharacters.includes('kael')) validCharacters.unshift('kael');
    if (!validWeapons.includes('fireSword')) validWeapons.unshift('fireSword');
    return {
      ...base,
      ...parsed,
      coins: Math.max(0, Number(parsed.coins ?? 0)),
      unlockedCharacters: validCharacters,
      unlockedWeapons: validWeapons,
      selectedCharacter: validCharacters.includes(parsed.selectedCharacter as CharacterId) ? parsed.selectedCharacter! : 'kael',
      selectedWeapon: validWeapons.includes(parsed.selectedWeapon as WeaponId) ? parsed.selectedWeapon! : 'fireSword',
      upgrades: parsed.upgrades ?? {},
      achievements: Array.isArray(parsed.achievements) ? parsed.achievements : [],
      settings: { ...base.settings, ...(parsed.settings ?? {}) },
    };
  } catch {
    return defaultSave();
  }
}

export function storeSave(data: SaveData) {
  try { localStorage.setItem(KEY, JSON.stringify(data)); } catch { /* Storage may be disabled; the current session still works. */ }
}

export const emptyUpgrades = (): UpgradeSet => ({ vitality: 0, focus: 0, fortune: 0 });
export const upgradeCost = (level: number, characterIndex: number) => Math.round((180 + characterIndex * 45) * (level + 1) * (1 + level * 0.35));

export interface RunResult {
  distance: number;
  score: number;
  coins: number;
  bosses: number;
  noHitBoss: boolean;
  ascended?: boolean;
  cause: string;
}

export interface ProgressResult { save: SaveData; unlockedAchievements: string[]; earnedRewards: number }

export function applyRunResult(previous: SaveData, result: RunResult): ProgressResult {
  const save: SaveData = {
    ...previous,
    coins: previous.coins + result.coins,
    totalCoins: previous.totalCoins + result.coins,
    totalRuns: previous.totalRuns + 1,
    bossesDefeated: previous.bossesDefeated + result.bosses,
    bestScore: Math.max(previous.bestScore, Math.round(result.score)),
    bestDistance: Math.max(previous.bestDistance, Math.round(result.distance)),
    unlockedCharacters: [...previous.unlockedCharacters],
    unlockedWeapons: [...previous.unlockedWeapons],
    achievements: [...previous.achievements],
  };
  const newly: string[] = [];
  let earnedRewards = 0;
  const tests: Record<string, boolean> = {
    firstBlood: true,
    century: result.bosses > 0 || previous.bossesDefeated > 0,
    bossSlayer: save.bossesDefeated >= 5,
    distance500: result.distance >= 500,
    distance1000: result.distance >= 1000,
    coin500: save.totalCoins >= 500,
    untouchable: result.noHitBoss,
    threeHeroes: save.unlockedCharacters.length >= 3,
    arsenal: save.unlockedWeapons.length === WEAPONS.length,
    ascended: Boolean(result.ascended),
  };
  for (const achievement of ACHIEVEMENTS) {
    if (!save.achievements.includes(achievement.id) && tests[achievement.id]) {
      save.achievements.push(achievement.id);
      save.coins += achievement.reward;
      earnedRewards += achievement.reward;
      newly.push(achievement.id);
    }
  }
  storeSave(save);
  return { save, unlockedAchievements: newly, earnedRewards };
}

export function checkCollectionAchievements(previous: SaveData): ProgressResult {
  const save: SaveData = { ...previous, achievements: [...previous.achievements] };
  const newly: string[] = [];
  let earnedRewards = 0;
  const tests: Record<string, boolean> = {
    threeHeroes: save.unlockedCharacters.length >= 3,
    arsenal: save.unlockedWeapons.length === WEAPONS.length,
  };
  for (const achievement of ACHIEVEMENTS) {
    if (tests[achievement.id] && !save.achievements.includes(achievement.id)) {
      save.achievements.push(achievement.id);
      save.coins += achievement.reward;
      earnedRewards += achievement.reward;
      newly.push(achievement.id);
    }
  }
  storeSave(save);
  return { save, unlockedAchievements: newly, earnedRewards };
}
